/*
 * @(#)RequestUtil.java  1.0, 2014-10-10
 */
package com.jnodeframework.util;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

/**
 * {@link HttpServletRequest} 관련 Util 클래스.
 *
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class RequestUtil {
	private Map<String, String> jsonParam = null;
	private HttpServletRequest request = null;
	private String templatePath  = null;
	private String collapseScope = null;

	/**
	 * {@link HttpServletRequest} 관련 Util 클래스의 생성자.
	 * 
	 * @param  request  처리할 {@link HttpServletRequest} 객체
	 */
	public RequestUtil(HttpServletRequest request) {
		String templatePath  = request.getServletContext().getInitParameter("jnode.templatePath");
		String collapseScope = request.getServletContext().getInitParameter("jnode.collapseScope");

		if (templatePath  == null)  templatePath  = "/WEB-INF/template";
		if (collapseScope == null)  collapseScope = "none";

		this.request       = request;
		this.templatePath  = templatePath;
		this.collapseScope = collapseScope;
	}

	/**
	 * Template path를 구분 안할 범위를 가져온다.
	 * 
	 * @return Scope of collapsed template path.
	 */
	public String getCollapseScope() {
		return this.collapseScope;
	}

	/**
	 * Cotent ID를 가져온다.
	 * 
	 * @return Content ID
	 */
	public String getContentId() {
		String statusCode = request.getParameter("error.status_code");
		String nodeType   = request.getParameter("nodeType");
		String nodeId     = request.getParameter("nodeId");

		String attrNodeId = (String)request.getAttribute("nodeId");
		if (!(attrNodeId == null || attrNodeId.trim().equals(""))) {
			nodeId = attrNodeId;
		}

		if (nodeId == null || nodeId.trim().equals(""))  nodeId = "/index";

		if (statusCode == null) {
			if (collapseScope.equals("none"))  return String.format("/%s%s", nodeType, nodeId);
			else                               return nodeId;
		} else {
			return String.format("/status/%s", nodeType);
		}
	}

	/**
	 * HTTP 상태 코드에 맞는 화면 View를 위임하는 {@link RequestDispatcher} 객체를 가져온다.
	 * 
	 * @param  statusCode  HTTP 상태 코드
	 * @return HTTP 상태 코드에 맞는 화면 View를 위임하는 {@link RequestDispatcher} 객체
	 */
	public RequestDispatcher getDispatcher(int statusCode) {
		request.setAttribute("javax.servlet.error.request_uri", request.getRequestURI());

		return request.getRequestDispatcher(String.format("%s/page/status/%d.jsp", templatePath, statusCode));
	}

	/**
	 * 화면에 View할 Template ID로 위임하는 {@link RequestDispatcher} 객체를 가져온다.
	 * 
	 * @param  templateId  화면에 View할 Template ID.
	 * @return 화면에 View할 Template ID로 위임하는 {@link RequestDispatcher} 객체.
	 */
	public RequestDispatcher getDispatcher(String templateId) {
		return request.getRequestDispatcher(templatePath + templateId + ".jsp");
	}

	/**
	 * 화면 View의 node에 삽입될 Template ID를 위임하는 {@link RequestDispatcher} 객체를 가져온다.
	 * 
	 * @param  nodeType  삽입될 Node Type.
	 * @param  nodeId    삽입될 Node ID.
	 * @return 화면에 View할 Template ID로 위임하는 {@link RequestDispatcher} 객체.
	 */
	public RequestDispatcher getDispatcher(String nodeType, String nodeId) {
		return request.getRequestDispatcher(String.format("%s/content/%s%s.jsp", templatePath, nodeType, nodeId));
	}

	/**
	 * Form Data 형식의 파라미터들을 담은 {@link HttpServletRequest}로부터 파라미터들을 {@link Map} 객체로 변환한다.
	 * 
	 * @return Client에서 요청한 파라미터들을 변환한 {@link Map} 객체
	 */
	public Map<String, ?> getFormParam() {
		Map<String, Object> formParam = new HashMap<String, Object>();

		Map<String, String[]> formParams = request.getParameterMap();
		Set<String> paramSet = formParams.keySet();
		for (String key : paramSet) {
			String[] values = formParams.get(key);
			if (values.length == 1)  formParam.put(key, values[0]);
			else                     formParam.put(key, values);
		}

		return formParam;
	}

	/**
	 * 배열을 담고 있는 JSON {@link String}을 {@link List}로 변환한다.
	 * 
	 * @param  listJson  배열을 담고 있는 JSON {@link String}.
	 * @param  type      Java 객체로 반영할 (@link Type}.
	 * @return 배열로 변환된 {@link List}.
	 */
	public List<?> getJsonList(String listJson, Type type) {
		return new Gson().fromJson(listJson, type);
	}

	/**
	 * JSON 형식의 파라미터들을 담은 {@link HttpServletRequest}로부터 파라미터들을 {@link Map} 객체로 변환한다.
	 * 
	 * @return Client에서 요청한 파라미터들을 변환한 {@link Map} 객체.
	 */
	public Map<String, String> getJsonParam() {
		if (jsonParam == null) {
			try {
				String reqJson = IOUtils.toString(request.getInputStream(), "UTF-8");
				jsonParam = new Gson().fromJson(reqJson, new TypeToken<Map<String,String>>(){}.getType());
			} catch(IOException | JsonSyntaxException e) {
				jsonParam = new HashMap<String, String>();
			}
		}

		return jsonParam;
	}

	/**
	 * 화면에 View할 Page ID를 가져온다.
	 * 
	 * @return 화면에 View할 Page ID.
	 */
	public String getPageId() {
		String servletPath = request.getServletPath();
		int    pathIndex   = servletPath.lastIndexOf("/");
		int    extIndex    = servletPath.lastIndexOf(".");

		if ((extIndex < 1) || (pathIndex > extIndex)) {
			if (!servletPath.endsWith("/"))  servletPath += "/";

			// NOTE: 디렉토리 요청에 따른 welcome 페이지의 확장자를 제외한 파일명을 index로 한정
			return servletPath + "index";
		} else {
			return servletPath.substring(0, extIndex);
		}
	}

	/**
	 * 상태코드에 따른 화면에 View할 Page ID를 가져온다.
	 * 
	 * @param  statusCode  상태 코드.
	 * @return 화면에 View할 Page ID.
	 */
	public String getPageId(int statusCode) {
		return String.format("/status/%d", statusCode);
	}

	/**
	 * 화면에 View할 Page ID를 가져온다.
	 * 
	 * @param  requestURI  Client단에서 요청받은 URI.
	 * @return 화면에 View할 Page ID.
	 */
	public String getPageId(String requestURI) {
		int contextPathLength = request.getContextPath().length();
		int extIndex          = requestURI.lastIndexOf(".");

		if (extIndex < 1) {
			String requestURIExcludedContextPath = requestURI.substring(contextPathLength);
			if (!requestURIExcludedContextPath.endsWith("/"))  requestURIExcludedContextPath += "/";

			// NOTE: 디렉토리로 요청에 따른 welcome 페이지의 확장자를 제외한 파일명을 index로 한정
			return requestURIExcludedContextPath + "index";
		} else {
			return requestURI.substring(contextPathLength, extIndex);
		}
	}

	/**
	 * 화면에 View할 Page의 상태코드를 가져온다.
	 * 
	 * @return 화면에 View할 Page의 상태코드.
	 */
	public int getPageStatusCode() {
		return getPageStatusCode(request.getRequestURI());
	}

	/**
	 * 화면에 View할 Page의 상태코드를 가져온다.
	 * 
	 * @param  requestURI  Client단에서 요청받은 URI.
	 * @return 화면에 View할 Template ID의 상태코드.
	 */
	public int getPageStatusCode(String requestURI) {
		String pageId = getPageId(requestURI);
		
		int statusCode = 200;

		if (pageId.matches("^/status/\\d\\d\\d$")) {
			try {
				statusCode = Integer.parseInt(pageId.substring(8));
			} catch (NumberFormatException e) {}
		}

		return statusCode;
	}

	/**
	 * Template ID를 가져온다.
	 * 
	 * @return Template ID
	 */
	public String getTemplateId() {
		String requireType = request.getParameter("requireType");
		String nodeType    = request.getParameter("nodeType");

		if (requireType == null || nodeType == null) {
			if (collapseScope.equals("none"))  return "/page" + getPageId();
			else                               return "/collapse" + getPageId();
		} else if (requireType.equals("content")) {
			if (request.getParameter("error.status_code") == null) {
				if (collapseScope.equals("none"))  return "/content"  + getContentId();
				else                               return "/collapse" + getContentId();
			} else {
				if (request.getServletPath().endsWith("/content/status/default.ejs")) {
					return "/content/status/default";
				} else {
					return "/content/status/"  + nodeType;
				}
			}
		} else {
			return "/controller/" + nodeType;
		}
	}

	/**
	 * 상태코드에 따른 레이아웃 페이지를 위한 Template ID를 가져온다.
	 * 
	 * @param  statusCode  상태 코드
	 * @return 상태코드에 따른 Template ID
	 */
	public String getTemplateId(int statusCode) {
		return "/page" + getPageId(statusCode);
	}

	/**
	 * Template path를 가져온다.
	 * 
	 * @return Template path
	 */
	public String getTemplatePath() {
		return this.templatePath;
	}
}