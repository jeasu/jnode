/*
 * @(#)DateFormatFunction.java  1.0, 2014-10-10
 */
package com.jnodeframework.util;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.google.gson.Gson;

/**
 * <CODE>$module$.date.Formatter</CODE> JavaScript 객체에서 사용할 날짜 포맷 관련 i18n JSON 객체를 생성하는 Function Class.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class DateFormatFunction {

	/**
	 * <CODE>$module$.date.Formatter</CODE> JavaScript 객체에서 사용할 날짜 포맷 관련 i18n JSON 객체를 생성한다.
	 * 
	 * @param  langObj  언어 정보를 나타내는 {@link String} 혹은 {@link Locale} 타입의 값.
	 * @return 날짜 포맷 관련 i18n JSON 객체.
	 */
	public static String getDateI18n(Object langObj) {
		Locale locale = null;

		if      (langObj instanceof Locale)  locale = (Locale)langObj;
		else if (langObj instanceof String)  locale = new Locale((String)langObj);
		else                                 throw new RuntimeException("Not defined parameter instance type.");

		return getDateI18nJson(locale);
	}

	/**
	 * <CODE>$module$.date.Formatter</CODE> JavaScript 객체에 정의되어 있지 않는 언어에 대해서만 날짜 포맷 관련 i18n JSON 객체를 생성한다.
	 * 
	 * @param  langObj  언어 정보를 나타내는 {@link String} 혹은 {@link Locale} 타입의 값.
	 * @return 날짜 포맷 관련 i18n JSON 객체
	 */
	public static String getDateI18nNotdefined(Object langObj) {
		Locale locale = null;

		if      (langObj instanceof Locale)  locale = (Locale)langObj;
		else if (langObj instanceof String)  locale = new Locale((String)langObj);
		else                                 throw new RuntimeException("Not defined parameter instance type.");

		String lang = locale.getLanguage();

		if (lang.equals("en") || lang.equals("ko") || lang.equals("zh") || lang.equals("ja")) {
			return "{\"lang\":\"" + lang + "\"}";
		} else {
			return getDateI18nJson(locale);
		}
	}

	/**
	 * <CODE>$module$.date.Formatter</CODE> 객체에서 사용할 날짜 포맷 관련 i18n JSON 객체를 생성한다.
	 * 
	 * @param  locale  Locale 정보
	 * @return 날짜 포맷 관련 i18n JSON 객체
	 */
	private static String getDateI18nJson(Locale locale) {
		DateFormatSymbols dateFormatSymbols = new DateFormatSymbols(locale);
		String[] shortMonthNames   = dateFormatSymbols.getShortMonths();
		String[] longMonthNames    = dateFormatSymbols.getMonths();
		String[] shortWeekdayNames = dateFormatSymbols.getShortWeekdays();
		String[] longWeekdayNames  = dateFormatSymbols.getWeekdays();
		String[] ampmNames         = dateFormatSymbols.getAmPmStrings();

		String[] monthNames   = new String[24];
		String[] weekdayNames = new String[14];

		for (int i = 0; i < 12; i++) {
			monthNames[i] = shortMonthNames[i];
		}

		for (int i = 0; i < 12; i++) {
			monthNames[i + 12] = longMonthNames[i];
		}

		for (int i = 0; i < 7; i++) {
			weekdayNames[i] = shortWeekdayNames[i + 1];
		}

		for (int i = 0; i < 7; i++) {
			weekdayNames[i + 7] = longWeekdayNames[i + 1];
		}

		Map<String, String[]> symbolsMap = new HashMap<String, String[]>();
		symbolsMap.put("MonthNames"  , monthNames  );
		symbolsMap.put("WeekdayNames", weekdayNames);
		symbolsMap.put("AmpmNames"   , ampmNames   );

		Map<String, String> dateStyleMap = new HashMap<String, String>();
		dateStyleMap.put("SHORT" , ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.SHORT , locale)).toPattern());
		dateStyleMap.put("MEDIUM", ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.MEDIUM, locale)).toPattern());
		dateStyleMap.put("LONG"  , ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.LONG  , locale)).toPattern());
		dateStyleMap.put("FULL"  , ((SimpleDateFormat)DateFormat.getDateInstance(DateFormat.FULL  , locale)).toPattern());

		Map<String, String> timeStyleMap = new HashMap<String, String>();
		timeStyleMap.put("SHORT" , ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.SHORT , locale)).toPattern());
		timeStyleMap.put("MEDIUM", ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.MEDIUM, locale)).toPattern());
		timeStyleMap.put("LONG"  , ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.LONG  , locale)).toPattern());
		timeStyleMap.put("FULL"  , ((SimpleDateFormat)DateFormat.getTimeInstance(DateFormat.FULL  , locale)).toPattern());

		Map<String, Map<String, ?>> dateMuiMap = new HashMap<String, Map<String, ?>>();
		dateMuiMap.put("Symbols"  , symbolsMap  );
		dateMuiMap.put("DateStyle", dateStyleMap);
		dateMuiMap.put("TimeStyle", timeStyleMap);

		Gson gson = new Gson();
		return gson.toJson(dateMuiMap);
	}
}