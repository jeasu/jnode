/*
 * @(#)TemplateResolver.java  1.3, 2014-03-28
 */
package com.jnodeframework.resolver;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.jnodeframework.util.RequestUtil;

/**
 * Template 파일을 Resolve해주는 Class.
 * 
 * @version 1.0, 2014-10-10
 * @version 1.3, 2014-03-28  레이아웃 페이지용 Template 파일을 Rendering하는 기능 추가
 * @author  Jeasu Kim
 */
public class TemplateResolver {
	private HttpServletRequest  request     = null;
	private HttpServletResponse response    = null;
	private ServletContext      context     = null;
	private RequestUtil         requestUtil = null;
	private String templatePath  = null;
	private String collapseScope = null;
	private String templateType  = null;
	private String templateExt   = null;

	/**
	 * Template Resolver 생성자.
	 * 
	 * @param  request   Client 요청 객체
	 * @param  response  Server 응답 객체
	 */
	public TemplateResolver(HttpServletRequest request, HttpServletResponse response) {
		requestUtil = new RequestUtil(request);

		this.request  = request;
		this.response = response;
		this.context  = request.getServletContext();
		this.templatePath  = requestUtil.getTemplatePath();
		this.collapseScope = requestUtil.getCollapseScope();

		String template = request.getParameter("template");

		if (template == null) {
			this.templateType = "ejs";
			this.templateExt  = ".ejs";
		} else {
			String[] separatedTemplates = template.split("\\.");

			if (separatedTemplates.length == 1) {
				this.templateType = template;

				if (template.equals("html"))  this.templateExt  = ".jsp";
				else                          this.templateExt  = "." + template;
			} else {
				this.templateType = separatedTemplates[0];
				this.templateExt  = "." + separatedTemplates[1];
			}
		}
	}

	/**
	 * Template Resolver 생성자.
	 * 
	 * <P>
	 * Template Type과 확장자가 다르면 점(.)을 구분자로 Type과 확장자를 연결해서 사용한다.
	 * 단, html Template Type일 경우에는 기본 확장자가 html이 아니라 jsp이다.
	 * 
	 * @param  request   Client 요청 객체
	 * @param  response  Server 응답 객체
	 * @param  template  Template 정보
	 */
	public TemplateResolver(HttpServletRequest request, HttpServletResponse response, String template) {
		requestUtil   = new RequestUtil(request);

		this.request  = request;
		this.response = response;
		this.context  = request.getServletContext();
		this.templatePath  = requestUtil.getTemplatePath();
		this.collapseScope = requestUtil.getCollapseScope();

		if (template == null)  template = request.getParameter("template");

		if (template == null) {
			this.templateType = "ejs";
			this.templateExt  = ".ejs";
		} else {
			String[] separatedTemplates = template.split("\\.");

			if (separatedTemplates.length == 1) {
				this.templateType = template;

				if (template.equals("html"))  this.templateExt  = ".jsp";
				else                          this.templateExt  = "." + template;
			} else {
				this.templateType = separatedTemplates[0];
				this.templateExt  = "." + separatedTemplates[1];
			}
		}
	}

	/**
	 * Template path를 구분 안할 범위를 가져온다.
	 * 
	 * @return Scope of collapsed template path.
	 */
	public String getCollapseScope() {
		return requestUtil.getCollapseScope();
	}

	/**
	 * Template 타입을 가져온다.
	 * 
	 * <P>
	 * 지정이 안되어 있으면 <CODE>ejs</CODE>가 return 된다.
	 * 
	 * @return  Template 타입
	 */
	public String getTemplateType() {
		return this.templateType;
	}

	/**
	 * Template 확장자를 가져온다.
	 * 
	 * <P>
	 * 지정이 안되어 있으면 Template 타입과 동일한 값이 return 된다.
	 * 단, Template 타입이 <CODE>html</CODE>이면 <CODE>jsp</CODE>가 return 된다.
	 * 
	 * @return  Template 확장자
	 */
	public String getTemplateExt() {
		return this.templateExt.substring(1);
	}

	/**
	 * 읽어온 Template 파일의 내용을 가져온다.
	 * 
	 * <P>
	 * Jnode Include를 통해 중첩으로 Include시킨 최종 값을 가져온다.
	 * 
	 * @param  templateId  확장자를 제외한 Template 파일 이름
	 * @param  encoding    문자셋
	 * @return Template 파일의 내용
	 * @throws IOException  Template 파일을 읽어오지 못할 때
	 */

	public String getTemplateValue(String templateId, String encoding) throws IOException {
		String containerDirname = templateId.substring(0, templateId.lastIndexOf("/") + 1);
		String value = IOUtils.toString(context.getResourceAsStream(templatePath + templateId + templateExt), encoding);

		Map<String, String> includePatternMap = new HashMap<String, String>();

		Matcher matcher = Pattern.compile("\\$include\\$\\s*\\(\\s*((\"[^\"|\\n]*\")|('[^'|\\n]*'))\\s*\\)").matcher(value);

		while(matcher.find()) {
			String matchedPattern  = matcher.group();

			// 들여쓰기 무시하고 체크
			if (includePatternMap.get(matchedPattern) == null) {
				String matchedCapture  = matcher.group(1);
				String includeFilename = matchedCapture.substring(1, matchedCapture.length() - 1);
				String indentValue     = null;

				int matchIndex  = matcher.start();
				int indentIndex = ("\n" + value).lastIndexOf("\n", matchIndex + 1);

				if (!includeFilename.startsWith("/"))  includeFilename = containerDirname + includeFilename;

				if (indentIndex > -1 && (matchIndex > indentIndex)) {
					// White space 문자에 대해서만 들여쓰기한다.
					indentValue = value.substring(indentIndex, matchIndex);
					if (!"".equals(indentValue.trim()))  indentValue = null;
				}

				// 들여쓰기까지 고려해서 최종 체크
				try {
					if (indentValue == null || includePatternMap.get(indentValue + matchedPattern) == null) {
						String includeValue = getTemplateValue(includeFilename, encoding);

						if (indentValue != null) {
							matchedPattern = indentValue + matchedPattern;
							includeValue   = indentValue + includeValue.replaceAll("\n", "\n" + indentValue);
						}

						includePatternMap.put(matchedPattern, includeValue);
					}
				} catch(NullPointerException e) {
					int lineNo = value.substring(0, matchIndex).split("\n", -1).length;
					throw new RuntimeException("There is no template file for the " + matchedPattern.trim() + "\n\tat " + this.templatePath + templateId + templateExt + " (Line:" + lineNo + ")");
				}
			}
		}

		Set<String> includePatternSet = includePatternMap.keySet();

		for (String includePattern : includePatternSet) {
			try {
				value = value.replaceAll("\\Q" + includePattern + "\\E", includePatternMap.get(includePattern));
			} catch (IllegalArgumentException e) {
				value = value.replace(includePattern, includePatternMap.get(includePattern));
			}
		}

		return value;
	}

	/**
	 * Form Data 형식의 파라미터들을 담은 {@link HttpServletRequest}로부터 파라미터들을 {@link Map} 객체로 변환한다.
	 * 
	 * @return Client에서 요청한 파라미터들을 변환한 {@link Map} 객체
	 */
	public Map<String, ?> getFormParam() {
		return requestUtil.getFormParam();
	}

	/**
	 * Template path를 가져온다.
	 * 
	 * @return Template path
	 */
	public String getTemplatePath() {
		return requestUtil.getTemplatePath();
	}

	/**
	 * Template ID를 가져온다.
	 * 
	 * @return Template ID
	 */
	public String getTemplateId() {
		return requestUtil.getTemplateId();
	}

	/**
	 * 상태코드에 따른 레이아웃 페이지를 위한 Template ID를 가져온다.
	 * 
	 * @param  statusCode  상태 코드
	 * @return 상태코드에 따른 Template ID
	 */
	public String getTemplateId(int statusCode) {
		return requestUtil.getTemplateId(statusCode);
	}

	/**
	 * 화면에 View할 Page ID를 가져온다.
	 * 
	 * @return 화면에 View할 Page ID
	 */
	public String getPageId() {
		return requestUtil.getPageId();
	}

	/**
	 * 화면에 View할 Page ID를 가져온다.
	 * 
	 * @param  requestURI  Client단에서 요청받은 URI.
	 * @return 화면에 View할 Page ID
	 */
	public String getPageId(String requestURI) {
		return requestUtil.getPageId(requestURI);
	}

	/**
	 * 상태코드에 따른 화면에 View할 Page ID를 가져온다.
	 * 
	 * @param  statusCode  상태 코드
	 * @return 화면에 View할 Page ID
	 */
	public String getPageId(int statusCode) {
		return requestUtil.getPageId(statusCode);
	}

	/**
	 * 화면에 View할 Page의 상태코드를 가져온다.
	 * 
	 * @return 화면에 View할 Page의 상태코드.
	 */
	public int getPageStatusCode() {
		return requestUtil.getPageStatusCode();
	}

	/**
	 * 화면에 View할 Page의 상태코드를 가져온다.
	 * 
	 * @param  requestURI  Client단에서 요청받은 URI.
	 * @return 화면에 View할 Resolver의 상태코드.
	 */
	public int getPageStatusCode(String requestURI) {
		return requestUtil.getPageStatusCode(requestURI);
	}

	/**
	 * Cotent ID를 가져온다.
	 * 
	 * @return Content ID
	 */
	public String getContentId() {
		return requestUtil.getContentId();
	}

	/**
	 * HTTP 상태 코드에 맞는 화면 View를 위임하는 {@link RequestDispatcher} 객체를 가져온다.
	 * 
	 * @param  statusCode  HTTP 상태 코드
	 * @return HTTP 상태 코드에 맞는 화면 View를 위임하는 {@link RequestDispatcher} 객체
	 */
	public RequestDispatcher getDispatcher(int statusCode) {
		return requestUtil.getDispatcher(statusCode);
	}

	/**
	 * 화면에 View할 Template ID로 위임하는 {@link RequestDispatcher} 객체를 가져온다.
	 * 
	 * @param  templateId 화면에 View할 Template ID.
	 * @return 화면에 View할 Template ID로 위임하는 {@link RequestDispatcher} 객체.
	 */
	public RequestDispatcher getDispatcher(String templateId) {
		return requestUtil.getDispatcher(templateId);
	}

	/**
	 * 화면 View의 node에 삽입될 Template ID를 위임하는 {@link RequestDispatcher} 객체를 가져온다.
	 * 
	 * @param  nodeType  삽입될 Node Type.
	 * @param  nodeId    삽입될 Node ID.
	 * @return 화면에 View할 Template ID로 위임하는 {@link RequestDispatcher} 객체.
	 */
	public RequestDispatcher getDispatcher(String nodeType, String nodeId) {
		return requestUtil.getDispatcher(nodeType, nodeId);
	}

	/**
	 * 배열을 담고 있는 JSON {@link String}을 {@link List}로 변환한다.
	 * 
	 * @param  listJson  배열을 담고 있는 JSON {@link String}.
	 * @param  type      Java 객체로 반영할 (@link Type}.
	 * @return 배열로 변환된 {@link List}.
	 */
	public List<?> getJsonList(String listJson, Type type) {
		return requestUtil.getJsonList(listJson, type);
	}

	/**
	 * Template 파일을 Template Type에 해당하는 Engine으로 UTF-8 문자셋으로 Rendering한다.
	 * 
	 * @throws IOException       Template 파일을 읽어오지 못하거나, Precompile한 값을 저장하지 못할 때
	 * @throws ServletException  JSP Template 파일로 foward시키지 못할 때
	 */
	public void renderTemplate() throws IOException, ServletException {
		renderTemplate((String)null);
	}

	public void renderTemplate(Map<String, ?> optionmap) throws IOException, ServletException {
		renderTemplate(optionmap, null);
	}

	public void renderTemplate(Map<String, ?> optionmap, String encoding) throws IOException, ServletException {
		renderTemplate(optionmap, encoding, (collapseScope.equals("template") ? "/collapse" : "/page"));
	}

	public void renderTemplate(Map<String, ?> optionmap, String encoding, String templatePrefix) throws IOException, ServletException {
		if (templateType.equalsIgnoreCase("html")) {
			Set<String> keySet = optionmap.keySet();
			for (String key : keySet) {
				request.setAttribute(key, optionmap.get(key));
			}

			renderTemplate((String)null, encoding, templatePrefix);
		} else {
			renderTemplate(new Gson().toJson(optionmap), encoding, templatePrefix);
		}
	}

	/**
	 * Template 파일을 Template Type에 해당하는 Engine으로 UTF-8 문자셋으로 Rendering한다.
	 * 
	 * @param  options  Template 파일을 Rendering할 JSON 옵션들
	 * @throws IOException       Template 파일을 읽어오지 못하거나, Precompile한 값을 저장하지 못할 때
	 * @throws ServletException  JSP Template 파일로 foward시키지 못할 때
	 */
	public void renderTemplate(String options) throws IOException, ServletException {
		renderTemplate(options, null);
	}

	/**
	 * Template 파일을 Template Type에 해당하는 Engine으로 Rendering한다.
	 * 
	 * @param  options   Template 파일을 Rendering할 JSON 옵션들
	 * @param  encoding  문자셋. <CODE>null</CODE>이면 UTF-8 문자셋으로 인식.
	 * @throws IOException       Template 파일을 읽어오지 못하거나, Precompile한 값을 저장하지 못할 때
	 * @throws ServletException  JSP Template 파일로 foward시키지 못할 때
	 */
	public void renderTemplate(String options, String encoding) throws IOException, ServletException {
		renderTemplate(options, encoding, (collapseScope.equals("template") ? "/collapse" : "/page"));
	}

	/**
	 * Template 파일을 Template Type에 해당하는 Engine으로 Rendering한다.
	 * 
	 * @param  options           Template 파일을 Rendering할 JSON 옵션들
	 * @param  encoding          문자셋. <CODE>null</CODE>이면 UTF-8 문자셋으로 인식.
	 * @param  templatePrefix    Template ID의 접두어 경로.
	 * @throws IOException       Template 파일을 읽어오지 못하거나, Precompile한 값을 저장하지 못할 때
	 * @throws ServletException  JSP Template 파일로 foward시키지 못할 때
	 */
	public void renderTemplate(String options, String encoding, String templatePrefix) throws IOException, ServletException {
		if (encoding == null)  encoding = "UTF-8";

		String templateId = templatePrefix + requestUtil.getPageId();

		try {
			if (templateType.equalsIgnoreCase("html")) {
				// RequestDispatcher dispatcher = requestUtil.getDispatcher(templateId);
				RequestDispatcher dispatcher = request.getRequestDispatcher(templatePath + templateId + templateExt);
				dispatcher.forward(request, response);
			} else {
				String compiledValue    = null;
				String sourceFileName   = templatePath + templateId + templateExt;
				String compiledFileName = templatePath + "/precompile" + templateId + templateExt;
				File   compiledFile     = null;

				boolean precompile = false;
				boolean existDir   = true;

				if (options == null) {
					options = "{}";

					precompile = true;
				}

				if (precompile) {
					File sourceFile = new File(context.getRealPath(sourceFileName));
					sourceFile.lastModified();

					compiledFile = new File(context.getRealPath(compiledFileName));
					if (compiledFile.exists()) {
						if (sourceFile.lastModified() < compiledFile.lastModified()) {
							compiledValue = IOUtils.toString(context.getResourceAsStream(compiledFileName), encoding);
						}
					} else {
						existDir = makeDirectory(compiledFile.getParentFile());
					}
				}

				if (compiledValue == null) {
					Map<String, String> serverMap = new HashMap<String, String>();
					serverMap.put("version"      , "1.6");
					serverMap.put("contextPath"  , request.getContextPath());
					serverMap.put("templatePath" , templatePath);
					serverMap.put("templateType" , templateType);
					serverMap.put("templateExt"  , getTemplateExt());
					serverMap.put("collapseScope", collapseScope);
					// $server$.topNode
					// $server$.topNodeName

					try {
						String value = getTemplateValue(templateId, encoding);

						ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");  // "nashorn"
						engine.eval(String.format("var $server$=%s", new Gson().toJson(serverMap)));
						engine.eval("$server$.topNode = (function() { return this; })()");
						engine.eval("$server$.topNodeName = (function(objTypeName) { return objTypeName.substring(8, objTypeName.length - 1).toLowerCase(); })(this.toString())");
						engine.eval("var global = $server$.topNode;");
						engine.eval("var window = $server$.topNode;");
						engine.eval("var console={log:function(message){print('[LOG(Jnode Template)] ' + message);},debug:function(message){print('[DEBUG(Jnode Template)] ' + message);},info:function(message){print('[INFO(Jnode Template)] ' + message);},warn:function(message){print('[WARN(Jnode Template)] ' + message);},error:function(message){print('[ERROR(Jnode Template)] ' + message);},trace:function(message){print('[TRACE(Jnode Template)] ' + message);}};");
						engine.eval(IOUtils.toString(context.getResourceAsStream("/WEB-INF/lib/template/" + templateType + ".js"), "UTF-8"));

						Invocable invocable = (Invocable)engine;
						compiledValue = (String)invocable.invokeFunction("renderTemplate", value, options);

						if (precompile && existDir && (compiledFile.exists() || compiledFile.createNewFile())) {
							IOUtils.write(compiledValue, new FileOutputStream(context.getRealPath(compiledFileName)), encoding);
						}
					} catch(ScriptException e) {
						throw new RuntimeException(e.getMessage());
					} catch(NoSuchMethodException e) {
						throw new RuntimeException(e.getMessage());
					}
				}

				response.setContentType("text/html; charset=" + encoding);
				PrintWriter out = response.getWriter();
				out.print(compiledValue);
			}
		} catch(NullPointerException e) {
			RequestDispatcher dispatcher = requestUtil.getDispatcher(404);
			dispatcher.forward(request, response);
		}
	}

	/**
	 * Template 파일을 Resolve한다.
	 * 
	 * @throws IOException  Template 파일을 읽어오지 못할 때
	 */
	public void resolveTemplate() throws IOException {
		resolveTemplate((String)null);
	}

	public void resolveTemplate(Map<String, ?> datamap) throws IOException {
		resolveTemplate(datamap, null);
	}

	public void resolveTemplate(Map<String, ?> datamap, String encoding) throws IOException {
		if (templateType.equalsIgnoreCase("html")) {
			Set<String> keySet = datamap.keySet();
			for (String key : keySet) {
				request.setAttribute(key, datamap.get(key));
			}
		}

		resolveTemplate(new Gson().toJson(datamap), encoding);
	}

	/**
	 * Template 파일을 UTF-8 문자셋으로 Resolve한다.
	 * 
	 * @param  dataset  Resolve한 Template 파일과 같이 넘겨줄 JSON 데이터들
	 * @throws IOException  Template 파일을 읽어오지 못할 때
	 */
	public void resolveTemplate(String dataset) throws IOException {
		resolveTemplate(dataset, null);
	}

	/**
	 * Template 파일을 UTF-8 문자셋으로 Resolve한다.
	 * 
	 * @param  dataset   Resolve한 Template 파일과 같이 넘겨줄 JSON 데이터들
	 * @param  encoding  문자셋. <CODE>null</CODE>이면 UTF-8 문자셋으로 인식.
	 * @throws IOException  Template 파일을 읽어오지 못할 때
	 */
	public void resolveTemplate(String dataset, String encoding) throws IOException {
		if (encoding == null)  encoding = "UTF-8";

		String delimiter      = null;
		String delimiterValue = null;
		String templateId     = requestUtil.getTemplateId();

		try {
			if (!(dataset == null || dataset.trim().equals(""))) {
				String plainDelimiter = "Jnode-Response-Delimiter_" + new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date());
				delimiter = new String(Base64.getEncoder().encodeToString(plainDelimiter.getBytes(encoding)));
				// delimiter = new String(Base64.encodeBase64(plainDelimiter.getBytes(encoding)));
				delimiterValue = "\"\"''<-------- " + delimiter + " -------->''\"\"";

				response.addHeader("Jnode-Response-Delimiter", delimiter);
			}

			if (templateType.equalsIgnoreCase("html")) {
				// RequestDispatcher dispatcher = requestUtil.getDispatcher(templateId);
				RequestDispatcher dispatcher = request.getRequestDispatcher(templatePath + templateId + templateExt);

				if (delimiter == null) {
					dispatcher.forward(request, response);
				} else {
					response.setContentType("text/plain; charset=" + encoding);
					PrintWriter out = response.getWriter();
					out.print(dataset);
					out.print(delimiterValue);

					dispatcher.include(request, response);
				}
			} else {
				String value = getTemplateValue(templateId, encoding);

				response.setContentType("text/plain; charset=" + encoding);
				PrintWriter out = response.getWriter();

				if (delimiter != null) {
					out.print(dataset);
					out.print(delimiterValue);
				}

				out.print(value);
			}
		} catch(NullPointerException e) {
			try {
				if (request.getParameter("error.status_code") == null) {
					this.templateExt  = ".ejs";
					String value      = null;
					String nodeType   = request.getParameter("nodeType");
					Map<String, Object> dataMap = new HashMap<String, Object>();

					try {
						value = getTemplateValue("/content/status/" + nodeType, encoding);
					} catch(NullPointerException npe) {
						value = getTemplateValue("/content/status/default", encoding);
						dataMap.put("status_file", "default");
					}

					Map<String, Object> errorData = new HashMap<String, Object>();
					errorData.put("status_code", 404);
					errorData.put("template"   , "ejs");
					errorData.put("message"    , "The template file for the " + nodeType + " node is not found.");
					errorData.put("stack"      , "The template file for the " + nodeType + " node is not found.");
					errorData.put("request_uri", request.getRequestURI());

					dataMap.put("error", errorData);

					if (delimiter == null) {
						String plainDelimiter = "Jnode-Response-Delimiter_" + new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(new Date());
						delimiter = new String(Base64.getEncoder().encodeToString(plainDelimiter.getBytes(encoding)));
						// delimiter = new String(Base64.encodeBase64(plainDelimiter.getBytes(encoding)));
						delimiterValue = "\"\"''<-------- " + delimiter + " -------->''\"\"";

						response.addHeader("Jnode-Response-Delimiter", delimiter);
					}

					response.setContentType("text/plain; charset=" + encoding);
					PrintWriter out = response.getWriter();
					out.print(new Gson().toJson(dataMap));
					out.print(delimiterValue);
					out.print(value);
				} else {
					response.setStatus(404);
				}
			} catch(Exception ex) {
				response.setStatus(500);
			}
		} catch(Exception e) {
			Map<String, Object> dataSet = new HashMap<String, Object>();
			dataSet.put("status_code", 500);
			dataSet.put("message"    , e.getMessage());
			dataSet.put("stack"      , e.getMessage());

			PrintWriter out = response.getWriter();
			out.print(new Gson().toJson(dataSet));

			response.setStatus(500);
		}
	}

	/**
	 * 부모 디렉토리를 포함해서 전체 경로의 디렉토리를 생성한다.
	 * 
	 * @param   path  디렉토리 파일 객체
	 * @return  생성 여부
	 */
	private boolean makeDirectory(File path) {
		if (path.exists()) {
			return true;
		} else {
			File parentDir = path.getParentFile();
			makeDirectory(parentDir);

			return path.mkdir();
		}
	}

	/*
	private String escapeRE(String value) {
		Pattern escaper = Pattern.compile("([^a-zA-z0-9])");
		return escaper.matcher(value).replaceAll("\\\\$1");
	}
	*/
}