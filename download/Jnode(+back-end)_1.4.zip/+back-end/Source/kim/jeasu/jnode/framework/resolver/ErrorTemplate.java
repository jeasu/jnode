/*
 * @(#)ErrorTemplate.java  1.0, 2014-10-10
 */
package kim.jeasu.jnode.framework.resolver;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kim.jeasu.jnode.framework.resolver.JsonResolver;
import kim.jeasu.jnode.framework.resolver.TemplateResolver;

import com.google.gson.Gson;

/**
 * Error Page의 내용을 JSON 형태로 처리해주는 Servlet
 *
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class ErrorTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Error Page의 내용을 JSON 형태로 처리해준다.
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String servletPath = request.getServletPath();
		String errorUri    = (String)request.getAttribute("javax.servlet.error.request_uri");
		String encoding    = getServletConfig().getInitParameter("encoding");

		if (errorUri == null)  errorUri = servletPath;
		else                   errorUri = errorUri.substring(request.getContextPath().length());

		boolean displayJsonFormat = false;

		if (request.getParameter("template") == null || request.getParameter("requireType") == null || request.getParameter("nodeType") == null) {
			String joinedJsonFormatPattern = getServletConfig().getInitParameter("json_format");

			if (joinedJsonFormatPattern != null) {
				String[] patterns = joinedJsonFormatPattern.trim().split("\n");

				for (String pattern : patterns) {
					pattern = pattern.trim();

					if (!pattern.equals("")) {
						if (pattern.endsWith("*")) {
							if (errorUri.startsWith(pattern.substring(0, pattern.length() - 1))) {
								displayJsonFormat = true;
								break;
							}
						} else if (pattern.startsWith("*")) {
							if (errorUri.endsWith(pattern.substring(1))) {
								displayJsonFormat = true;
								break;
							}
						} else {
							if (errorUri.equals(pattern)) {
								displayJsonFormat = true;
								break;
							}
						}
					}
				}
			}
		} else {
			displayJsonFormat = true;
		}

		Exception exception = (Exception)request.getAttribute("javax.servlet.error.exception");

		String errorMessage = (String)request.getAttribute("javax.servlet.error.message");
		String debugMessage = null;
		
		if (exception != null)  debugMessage = exception.getMessage();

		if (errorMessage == null || errorMessage.equals(""))  errorMessage = debugMessage;
		if (debugMessage == null || debugMessage.equals(""))  debugMessage = errorMessage;

		if (errorMessage == null || errorMessage.equals("")) {
			debugMessage = errorMessage = exception.getClass().getName();
		}

		if (displayJsonFormat) {
			Map<String, Object> dataSet = new HashMap<String, Object>();
			dataSet.put("status_code", request.getAttribute("javax.servlet.error.status_code"));
			dataSet.put("message"    , errorMessage);
			dataSet.put("stack"      , debugMessage);
			dataSet.put("request_uri", errorUri);

			new JsonResolver(request, response).resolve(new Gson().toJson(dataSet), encoding);
		} else if (response.getStatus() == 200) {
			response.sendError(404);
		} else {
			request.setAttribute("error_message", errorMessage);
			request.setAttribute("error_stack"  , debugMessage);

			new TemplateResolver(request, response, "html").renderTemplate(null, encoding);
		}
	}
}