/*
 * @(#)NodeTemplate.java  1.0, 2014-10-10
 */
package kim.jeasu.jnode.framework.resolver;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Web Application의 Node Element를 처리할 Template 파일을 <CODE>/WEB-INF/template</CODE>에서 찾도록 설정해 주는 Servlet.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class NodeTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Web Application의 Node Element를 처리할 Template 파일을 <CODE>/WEB-INF/template</CODE>에서 찾아 출력한다.
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String template = getServletConfig().getInitParameter("template");
		String encoding = getServletConfig().getInitParameter("encoding");

		new TemplateResolver(request, response, template).resolveTemplate(null, encoding);
	}

	/**
	 * Node Element를 처리할 Template 파일은 POST 방식으로 요청할 때만 응답을 하고, POST 방식으로 요청할 때는 405 에러 페이지 대신 404 에러 페이지를 출력하여
	 * 정상적인 경로가 아닌 경로로 요청할 때 실제 Template 파일이 있는지 여부를 알 수 없게 한다.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.sendError(404, "File Not Found");
	}
}