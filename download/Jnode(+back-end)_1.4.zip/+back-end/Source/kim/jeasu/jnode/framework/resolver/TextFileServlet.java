/*
 * @(#)TextFileServlet.java  1.0, 2014-10-10
 */
package kim.jeasu.jnode.framework.resolver;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

/**
 * 텍스트 파일 관련 처리를 도와주는 Servlet.
 * 
 * <P>
 * <B>[텍스트 파일 업로드 처리]</B>
 * request의 파라미터가 <CODE>multipart/form-data</CODE> 형식으로 넘어오면
 * Text 파일이 클라이언트로부터 upload된 것으로 간주하고 이를 파싱하여
 * request의 attribute에 <CODE>multipartParam</CODE>이라는 이름으로 파라미터 정보를 담아
 * <CODE>forward_uri</CODE> 파라미터에 해당하는 페이지로 forward시킨다.
 * 이를 위해 내부적으로 사용되는 파라미터들은 아래와 같으며 
 * 이때, 내부적으로 사용되는 파라미터와 동일한 이름의 파라미터가 필요할 경우에는 배열의 다음번째 값들에 담으면 된다.
 * <PRE>
 *     forward_uri  <CODE>multipart/form-data</CODE> 형식으로 넘어온 파라미터들을 <CODE>multipartParam</CODE>이라는 이름으로 담은 후 forward시킬 URI address
 *     encoding     upload된 text 파일을 읽어올 encoding type
 *     
 *     upload된 text file의 field name index에 해당하는 encoding 배열의 index가 내용을 읽어올 encoding type으로 사용되다.
 *     만약 upload된 text file의 field name 수보다 encoding 배열 수가 적으면 마지막 배열의 값으로 나머지 encoding type으로 사용되고,
 *     encoding 값이 없으면 디폴트로 <CODE>UTF-8</CODE>로 사용된다.
 *     단, 동일한 upload된 text file의 field name이 복수로 되어 있어도 encoding은 하나의 배열 index로만 처리된다.
 * </PRE>
 * 파라미터들은 <CODE>multipartParam</CODE>에 아래의 규칙으로 담긴다.
 * <PRE>
 *     단일 일반 파라미터           <CODE>Map&lt;String, String&gt;</CODE> 형식으로 field name, field value가 담긴다.
 *     복수 일반 파라미터           <CODE>Map&lt;String, String[]&gt;</CODE> 형식으로 하나의 field name에 배열로 복수개의 field value가 담긴다.
 *     단일 Upload file 파라미터  <CODE>Map&lt;String, Map&lt;String, Object&gt;&gt;</CODE> 형식으로 field name에 파일 text file 정보가 담긴다.
 *     복수 Upload file 파라미터  <CODE>Map&lt;String, Map&lt;String, Object&gt;[]&gt;</CODE> 형식으로 하나의 field name에 파일 text file 정보가 배열로 담긴다.
 *     
 *     upload된 text file 정보는 아래와 같은 key에 정보의 값들이 담긴다.
 *         name         upload된 text file 이름.
 *         value        upload된 text file의 내용을 읽어온 {@link String} 값.
 *         inputStream  upload된 text file의 내용의 {@link InputStream} 값. 만약, value의 글씨가 깨진다면 inputStream을 통해 직접 {@link String}으로 파싱할 수 있다.
 *         contentType  upload된 file의 Content Type.
 *         size         upload된 file의 크기의 <CODE>long</CODE> 값.
 * </PRE>
 * 
 * <P>
 * <B>[URL의 텍스트 파일을 로컬 도메인처럼 Proxy 처리]</B>
 * request의 파라미터가 <CODE>application/x-www-form-urlencoded</CODE> 형식으로 넘어오면
 * URL의 텍스트 파일을 파싱하는 것으로 간주하고 <CODE>url</CODE> 파라미터에 해당하는 페이지를 파싱해서 화면에 출력한다.
 * 내부적으로 사용되는 파라미터들은 아래와 같으며 이외의 값들은 <CODE>url</CODE> 파라미터에 해당하는 페이지를 호출하는 파라미터로 사용된다.
 * 이때, 내부적으로 사용되는 파라미터와 동일한 이름의 파라미터가 필요할 경우에는 배열의 다음번째 값들에 담으면 된다.
 * 
 * <PRE>
 *     url          Text 파일을 읽어올 URL address
 *     encoding     URL 주소에서 읽어온 Text 파일의 encoding type
 *     contenttype  URL 주소의 Text 파일을 읽어올 request의 content type
 *     accept       URL 주소의 Text 파일을 읽어올 response의 accept type
 * </PRE>
 * 
 * encoding이 없으면 <CODE>UTF-8</CODE>로 처리되며,
 * contenttype이 없으면 <CODE>application/x-www-form-urlencoded;charset=${request_encoding}</CODE>로 처리된다.
 * <CODE>${request_encoding}</CODE>은 request의 CharacterEncoding이며 설정된 값이 없으면 <CODE>UTF-8</CODE>로 처리된다.
 * accept는 없으면 무시한다.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
@WebServlet(urlPatterns = "/servlet/kim.jeasu.jnode.framework.resolver.TextFileServlet")
public class TextFileServlet extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * POST 요청일 때 업로드 혹은 Server URL로부터 Text file을 읽어온다.
	 * 
	 * <P>
	 * encoding type이 <CODE>multipart/form-data</CODE>이면 사용자의 Local 경로에 있는 Text File을 Upload해서 읽어오고,
	 * encoding type이 <CODE>application/x-www-form-urlencoded</CODE>이면 Server URL로부터 Text File을 읽어온다.
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		if (origin == null || origin.indexOf(host) < 0) {
			// 타 도메인에서 요청온 것이므로 차단한다.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			if (ServletFileUpload.isMultipartContent(request)) {
				seriveClientTextFile(request, response);
			} else {
				serviceProxy(request, response);
			}
		}
	}

	/**
	 * GET 요청일 때 Server URL로부터 Text file을 읽어온다.
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		if (origin == null || origin.indexOf(host) < 0) {
			// 타 도메인에서 요청온 것이므로 차단한다.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			serviceProxy(request, response);
		}
	}

	/**
	 * 업로드한 파일로부터 Text file을 읽어온다.
	 * 
	 * @param  request   Text File을 읽어오기 위해 필요한 파라미터들을 담은 {@link HttpServletRequest} 객체
	 * @param  response  Text File을 읽어온 정보를 출력하기 위한 {@link HttpServletResponse} 객체
	 * @throws IOException       Text File을 읽어올 수 없을 때 발생
	 * @throws ServletException  dispatch시킬 수 없을 때
	 */
	@SuppressWarnings("unchecked")
	private void seriveClientTextFile(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		try {
			String encoding = request.getCharacterEncoding();

			Map<String,Object> paramMap = new HashMap<String,Object>();

			// 복수값에 대한 처리를 위한 변수
			List<String> multiParamList = new ArrayList<String>();
			List<String> multiFileList = new ArrayList<String>();
			List<String> fileList = new ArrayList<String>();
			ArrayList<String> arrlstParam = null;
			ArrayList<Map<String,Object>> arrlstFile = null;

			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);

			List<FileItem> items = upload.parseRequest(request);

			String fieldName  = null;
			String fieldValue = null;

			for (FileItem item : items) {
				fieldName  = item.getFieldName();

				if (item.isFormField()) {
					// 일반 form 필드일때
					if (encoding == null)  fieldValue = item.getString();
					else                   fieldValue = item.getString(encoding);

					if (paramMap.containsKey(fieldName)) {
						// 복수값에 대한 처리
						if (paramMap.get(fieldName) instanceof java.lang.String) {
							// 복수값임을 처음 알게 되었을 때
							multiParamList.add(fieldName);
							arrlstParam = new ArrayList<String>();
							arrlstParam.add((String)paramMap.get(fieldName));
							arrlstParam.add(fieldValue);
						} else {
							// 이미 복수값임을 알고 있을 때
							arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
							arrlstParam.add(fieldValue);
						}

						paramMap.put(fieldName, arrlstParam);
					} else {
						// 단수값에 대한 처리
						paramMap.put(fieldName, fieldValue);
					}
				} else {
					// binary 파일일때
					Map<String,Object> textFileMap = new HashMap<String,Object>();
					textFileMap.put("name"       , item.getName());
					textFileMap.put("contentType", item.getContentType());
					textFileMap.put("inputStream", item.getInputStream());
					textFileMap.put("size"       , item.getSize());

					if (paramMap.containsKey(fieldName)) {
						// 복수값에 대한 처리
						if (paramMap.get(fieldName) instanceof java.util.Map) {
							// 복수값임을 처음 알게 되었을 때
							multiFileList.add(fieldName);
							arrlstFile = new ArrayList<Map<String,Object>>();
							arrlstFile.add((Map<String,Object>)paramMap.get(fieldName));
							arrlstFile.add(textFileMap);
						} else {
							// 이미 복수값임을 알고 있을 때
							arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
							arrlstFile.add(textFileMap);
						}

						paramMap.put(fieldName, arrlstFile);
					} else {
						// 단수 파일에 대한 처리
						paramMap.put(fieldName, textFileMap);
						fileList.add(fieldName);
					}
				}
			}

			// ArrayList로 임시로 저장했던 복수값을 String[]로 변환
			for (int i = 0; i < multiParamList.size(); i++) {
				fieldName = (String)multiParamList.get(i);
				arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstParam.toArray(new String[arrlstParam.size()]));
			}

			// ArrayList로 임시로 저장했던 복수값을 Map[]로 변환
			for (int i = 0; i < multiFileList.size(); i++) {
				fieldName = (String)multiFileList.get(i);
				arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstFile.toArray(new Map[arrlstFile.size()]));
			}

			// InputStream으로 담았던 파일 정보를 String으로 변환한다.
			int fileSize = fileList.size();
			if (encoding == null)  encoding = "UTF-8";
			String[] fileEncodings = null;

			if (paramMap.containsKey("encoding")) {
				if (paramMap.get("encoding") instanceof java.lang.String) {
					fileEncodings = new String[1];
					fileEncodings[0] = (String)paramMap.get("encoding");
				} else {
					fileEncodings = (String[])paramMap.get("encoding");
				}

				String lastFileEncoding = fileEncodings[fileEncodings.length - 1];

				for (int i = fileEncodings.length; i < fileSize; i++) {
					fileEncodings[i] = lastFileEncoding;
				}
			} else {
				fileEncodings = new String[fileSize];
				for (int i = 0; i < fileSize; i++) {
					fileEncodings[i] = encoding;
				}
			}

			for (int i = 0; i < fileSize; i++) {
				fieldName = (String)fileList.get(i);

				Object objFile =paramMap.get(fieldName);

				if (objFile instanceof java.util.Map) {
					Map<String,Object> textFileMap = (Map<String,Object>)objFile;

					String fileValue = IOUtils.toString((InputStream)textFileMap.get("inputStream"), fileEncodings[i]);
					if (fileValue.startsWith("\ufeff"))  fileValue = fileValue.substring(1);  // UTF-8 + BOM 인코딩 타입을 표시하는 문자제거
					textFileMap.put("value", fileValue);

					paramMap.put(fieldName, textFileMap);
				} else {
					Map<String,Object>[] textFileMaps = (Map<String,Object>[])objFile;

					for (int j = 0; j < textFileMaps.length; j++) {
						String fileValue = IOUtils.toString((InputStream)textFileMaps[j].get("inputStream"), fileEncodings[i]);
						if (fileValue.startsWith("\ufeff"))  fileValue = fileValue.substring(1);  // UTF-8 + BOM 인코딩 타입을 표시하는 문자제거
						textFileMaps[j].put("value", fileValue);
					}

					paramMap.put(fieldName, textFileMaps);
				}
			}

			request.setAttribute("multipartParam", paramMap);

			Object forwardUriObj = paramMap.get("forward_uri");
			String forwardUri = null;
			if (forwardUriObj instanceof String) {
				forwardUri = (String)forwardUriObj;
			} else if (forwardUriObj instanceof String[]) {
				forwardUri = ((String[])forwardUriObj)[0];
			}

			if (forwardUri == null) {
				throw new RuntimeException("forward_uri parameter is required.");
			}

			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(forwardUri);
			dispatcher.forward(request, response);
		} catch (FileUploadException e) {
			throw new RuntimeException("Cannot load the local file.", e);
		}
	}
	

	/**
	 * 다른 도메인의 Server URL로부터 Text file을 읽어온다.
	 * 
	 * @param  request   Text File을 읽어오기 위해 필요한 파라미터들을 담은 {@link HttpServletRequest} 객체
	 * @param  response  Text File을 읽어온 정보를 출력하기 위한 {@link HttpServletResponse} 객체
	 * @throws IOException  Text File을 읽어올 수 없을 때 발생
	 */
	private void serviceProxy(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String targetUrl   = request.getParameter("url");
		String encoding    = request.getParameter("encoding");
		String contenttype = request.getParameter("contenttype");
		String accept      = request.getParameter("accept");
		String reqEncoding = request.getCharacterEncoding();
		String paramValue  = getParamValue(request);

		if (targetUrl   == null)  throw new RuntimeException("The URL address to load is empty");
		if (encoding    == null)  encoding    = "UTF-8";
		if (reqEncoding == null)  reqEncoding = "UTF-8";
		if (contenttype == null)  contenttype = "application/x-www-form-urlencoded;charset=" + reqEncoding;

		URL url = new URL(targetUrl);

		HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
		urlConn.setRequestMethod(request.getMethod());
		urlConn.setDoOutput(true);
		urlConn.setDoInput(true);
		urlConn.setUseCaches(false);
		// urlConn.setFollowRedirects(false);

		urlConn.setRequestProperty("Content-Type", contenttype);

		if (accept != null)  urlConn.setRequestProperty("Accept", accept);

		if (paramValue != null) {
			DataOutputStream  output = new DataOutputStream(urlConn.getOutputStream());
			output.writeBytes(paramValue);
		}

		String urlValue = IOUtils.toString(urlConn.getInputStream(), encoding);
		if (urlValue.startsWith("\ufeff"))  urlValue = urlValue.substring(1);  // UTF-8 + BOM 인코딩 타입을 표시하는 문자제거

		response.setContentType("text/plain; charset=" + encoding);
		PrintWriter out = response.getWriter();
		out.print(urlValue);
	}

	/**
	 * Server URL로부터 Text file을 읽어오기 위해 필요한 파라미터들을 문자열로 가져온다.
	 * 
	 * 파라미터 중 <CODE>url, encoding, contenttype, accept</CODE>은 Server URL로부터 Text File을 읽어오기 위해
	 * Servlet 내부에서 사용되는 값들이므로, 이들과 동일한 이름의 파라미터가 필요할 경우에는 배열의 두번째에 담기도록 해서 보내면 된다.
	 * 
	 * @param  request   Text File을 읽어오기 위해 필요한 파라미터들을 담은 {@link HttpServletRequest} 객체
	 * @return 파라미터들을 문자열로 바꾼 {@link String} 객체
	 * @throws UnsupportedEncodingException  {@link HttpServletRequest} 객체에서 문자로 변경할 때 지원하지 않는 encoding이 선언되었을 때
	 */
	private String getParamValue(HttpServletRequest request) throws UnsupportedEncodingException {
		Enumeration<String> enumParamName = request.getParameterNames();
		String encoding = request.getCharacterEncoding();

		if (encoding == null)  encoding = "UTF-8";

		StringBuffer parameterBuffer = new StringBuffer();

		while (enumParamName.hasMoreElements()) {
			String paramName = enumParamName.nextElement();
			String[] values = request.getParameterValues(paramName);
			int startIndex = 0;

			if (paramName.equals("url") || paramName.equals("encoding") || paramName.equals("contenttype") || paramName.equals("accept")) {
				startIndex = 1;
			}

			for (int i = startIndex; i < values.length; i++) {
				parameterBuffer.append("&").append(paramName).append("=").append(URLEncoder.encode(values[i], encoding));
			}
		}

		String paramValue = parameterBuffer.toString();

		if (paramValue.equals("")) {
			return null;
		} else {
			return paramValue.substring(1);
		}
	}
}
