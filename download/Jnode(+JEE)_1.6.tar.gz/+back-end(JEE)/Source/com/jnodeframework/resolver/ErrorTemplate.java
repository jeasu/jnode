/*
 * @(#)ErrorTemplate.java  1.0, 2014-10-10
 */
package com.jnodeframework.resolver;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * Error Page의 내용을 JSON 형태로 처리해주는 Servlet
 *
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class ErrorTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Error Page의 내용을 JSON 형태로 처리해준다.
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String servletPath = request.getServletPath();
		String errorUri    = (String)request.getAttribute("javax.servlet.error.request_uri");
		String encoding    = getServletConfig().getInitParameter("encoding");

		if (errorUri == null)  errorUri = servletPath;
		else                   errorUri = errorUri.substring(request.getContextPath().length());

		boolean displayJsonFormat = false;
		String requestMethod = request.getMethod().toLowerCase();

		if (request.getParameter("template") == null || request.getParameter("requireType") == null || request.getParameter("nodeType") == null) {
			String joinedJsonFormatPatternMethod = getServletConfig().getInitParameter("json_format");

			if (joinedJsonFormatPatternMethod != null) {
				String[] patternMethods = joinedJsonFormatPatternMethod.trim().split("\n");

				for (String patternMethod : patternMethods) {
					patternMethod = patternMethod.trim();

					if (!patternMethod.equals("")) {
						String[] sepratedPatternMethod = patternMethod.split(";");
						String pattern = patternMethod;
						String method  = "*";

						if (sepratedPatternMethod.length == 2) {
							pattern = sepratedPatternMethod[0].trim();
							method  = sepratedPatternMethod[1].trim().toLowerCase();
						}

						if (pattern.endsWith("*")) {
							if (errorUri.startsWith(pattern.substring(0, pattern.length() - 1))) {
								if (method.equals("*") || requestMethod.equals(method)) {
									displayJsonFormat = true;
									break;
								}
							}
						} else if (pattern.startsWith("*")) {
							if (errorUri.endsWith(pattern.substring(1))) {
								if (method.equals("*") || requestMethod.equals(method)) {
									displayJsonFormat = true;
									break;
								}
							}
						} else {
							if (errorUri.equals(pattern)) {
								if (method.equals("*") || requestMethod.equals(method)) {
									displayJsonFormat = true;
									break;
								}
							}
						}
					}
				}
			}
		} else {
			displayJsonFormat = true;
		}

		Exception exception = (Exception)request.getAttribute("javax.servlet.error.exception");

		String errorMessage = (String)request.getAttribute("javax.servlet.error.message");
		String debugMessage = null;

		if (exception != null) {
			StringWriter sw = new StringWriter();
			exception.printStackTrace(new PrintWriter(sw));
			debugMessage = sw.toString();
		}

		if (errorMessage == null || errorMessage.equals(""))  errorMessage = debugMessage;
		if (debugMessage == null || debugMessage.equals(""))  debugMessage = errorMessage;

		if (errorMessage == null || errorMessage.equals("")) {
			debugMessage = errorMessage = exception.getClass().getName();
		}

		if (displayJsonFormat) {
			Map<String, Object> dataSet = new HashMap<String, Object>();
			dataSet.put("status_code" , request.getAttribute("javax.servlet.error.status_code"));
			dataSet.put("message"     , errorMessage.trim());
			dataSet.put("stack"       , debugMessage.trim());
			dataSet.put("request_uri" , errorUri);
			dataSet.put("html_message", request.getAttribute("html_message"));

			new JsonResolver(request, response).resolve(new Gson().toJson(dataSet), encoding);
		} else if (response.getStatus() == 200) {
			response.sendError(404);
		} else {
			request.setAttribute("error_message", errorMessage.trim());
			request.setAttribute("error_stack"  , debugMessage.trim());

			new TemplateResolver(request, response, "html").renderTemplate((String)null, encoding, "/page");
		}
	}
}