/*
 * @(#)JsonResolver.java  1.3, 2014-03-28
 */
package com.jnodeframework.resolver;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.jnodeframework.util.RequestUtil;

/**
 * JSON Response 결과를 Resolve해주는 Class.
 * 
 * @version 1.3, 2014-03-28
 * @author  Jeasu Kim
 */
public class JsonResolver {
	private HttpServletResponse response    = null;
	private RequestUtil         requestUtil = null;

	/**
	 * JSON Resolver 생성자.
	 * 
	 * @param request   Client 요청 객체
	 * @param response  Server 응답 객체
	 */
	public JsonResolver(HttpServletRequest request, HttpServletResponse response) {
		requestUtil = new RequestUtil(request);

		this.response = response;
	}

	/**
	 * 배열을 담고 있는 JSON {@link String}을 {@link List}로 변환한다.
	 * 
	 * @param   listJson  배열을 담고 있는 JSON {@link String}.
	 * @param   type      Java 객체로 반영할 Type.
	 * @return  배열로 변환된 {@link List}
	 */
	public List<?> getJsonList(String listJson, Type type) {
		return requestUtil.getJsonList(listJson, type);
	}

	/**
	 * JSON 형식의 파라미터들을 담은 {@link HttpServletRequest}로부터 파라미터들을 {@link Map} 객체로 변환한다.
	 * 
	 * @return Client에서 요청한 파라미터들을 변환한 {@link Map} 객체
	 */
	public Map<String,String> getJsonParam() {
		return requestUtil.getJsonParam();
	}

	/**
	 * 화면에 View할 Page ID를 가져온다.
	 * 
	 * @return 화면에 View할 Page ID
	 */
	public String getPageId() {
		return requestUtil.getPageId();
	}

	/**
	 * 화면에 View할 Page ID를 가져온다.
	 * 
	 * @param  requestURI  Client단에서 요청받은 URI.
	 * @return 화면에 View할 Page ID
	 */
	public String getPageId(String requestURI) {
		return requestUtil.getPageId(requestURI);
	}

	/**
	 * 상태코드에 따른 화면에 View할 Page ID를 가져온다.
	 * 
	 * @param  statusCode  상태 코드
	 * @return 화면에 View할 Page ID
	 */
	public String getPageId(int statusCode) {
		return requestUtil.getPageId(statusCode);
	}

	/**
	 * 화면에 View할 Page의 상태코드를 가져온다.
	 * 
	 * @return 화면에 View할 Page의 상태코드.
	 */
	public int getPageStatusCode() {
		return requestUtil.getPageStatusCode();
	}

	/**
	 * 화면에 View할 Page의 상태코드를 가져온다.
	 * 
	 * @param  requestURI  Client단에서 요청받은 URI.
	 * @return 화면에 View할 Resolver의 상태코드.
	 */
	public int getPageStatusCode(String requestURI) {
		return requestUtil.getPageStatusCode(requestURI);
	}

	/**
	 * Java {@link Map} 객체를 JSON 형태의 UTF-8 문자셋으로 변환하여 Resolve한다.
	 * 
	 * @param  datamap      JSON 형태로 변환해서 Response로 응답할 Java {@link Map} 객체.
	 * @throws IOException  {@link HttpServletResponse} 객체에 넘겨줄 JSON 데이터들을 출력하지 못할 때
	 * @since  Jnode Framework 1.6
	 */
	public void resolve(Map<String, ?> datamap) throws IOException {
		resolve(datamap, null);
	}

	/**
	 * Java {@link Map} 객체를 JSON 형태로 변환하여 Resolve한다.
	 * 
	 * @param  datamap      JSON 형태로 변환해서 Response로 응답할 Java {@link Map} 객체.
	 * @param  encoding     문자셋. <CODE>null</CODE>이면 UTF-8 문자셋으로 인식.
	 * @throws IOException  {@link HttpServletResponse} 객체에 넘겨줄 JSON 데이터들을 출력하지 못할 때
	 * @since  Jnode Framework 1.6
	 */
	public void resolve(Map<String, ?> datamap, String encoding) throws IOException {
		resolve(new Gson().toJson(datamap), encoding);
	}

	/**
	 * JSON Response 결과를 UTF-8 문자셋으로 Resolve한다.
	 * 
	 * @param  dataset      Response로 응답할 JSON 형태의 {@link String}.
	 * @throws IOException  {@link HttpServletResponse} 객체에 넘겨줄 JSON 데이터들을 출력하지 못할 때
	 */
	public void resolve(String dataset) throws IOException {
		resolve(dataset, null);
	}

	/**
	 * JSON Response 결과를 Resolve한다.
	 * 
	 * @param  dataset      Response로 응답할 JSON 형태의 {@link String}.
	 * @param  encoding     문자셋. <CODE>null</CODE>이면 UTF-8 문자셋으로 인식.
	 * @throws IOException  {@link HttpServletResponse} 객체에 넘겨줄 JSON 데이터들을 출력하지 못할 때
	 */
	public void resolve(String dataset, String encoding) throws IOException {
		if (encoding == null)  encoding = "UTF-8";

		response.setContentType("application/json; charset=" + encoding);
		PrintWriter out = response.getWriter();
		out.print(dataset);
	}
}