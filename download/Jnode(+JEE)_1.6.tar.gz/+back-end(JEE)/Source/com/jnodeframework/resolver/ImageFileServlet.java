/*
 * @(#)ImageFileServlet.java  1.0, 2014-10-10
 */
package com.jnodeframework.resolver;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// import org.apache.commons.codec.binary.Base64;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

/**
 * Client의 이미지 파일을 업로드하거나, 타 도메인의 URL로부터 읽어온 이미지 파일을 로컬 서버의 경로에 별도로 저장하지 않고
 * Template 파일(HTML, JSP, EJS, ...) 내부 코드만으로 사용 가능하게 Base64 문자열로 이미지를 변환하는 Servlet.
 * 
 * <P>
 * <CODE>ImageFileServlet</CODE>은 2가지 방식으로 이미지 파일을 읽어온다.
 * encoding type을 <CODE>multipart/form-data</CODE>로 요청을 하면 Client로부터 업로드한 이미지 파일을 읽어 출력하고,
 * encoding type을 <CODE>application/x-www-form-urlencoded</CODE>로 요청을 하면서 <CODE>url</CODE> 파라미터로 이미지 파일을 읽어올 URL 주소를 넘기게 되면
 * <CODE>url</CODE>에 해당하는 이미지 파일을 읽어온다.
 * 
 * <P>
 * <B>[이미지 파일 업로드 처리]</B>
 * 
 * <P>
 * <CODE>request</CODE>의 파라미터가 <CODE>multipart/form-data</CODE> 형식으로 넘어오면 Image 파일이 클라이언트로부터 upload된 것으로 간주하고 이를 파싱하여
 * <CODE>request</CODE>의 attribute에 <CODE>multipart_param</CODE>이라는 이름으로 파라미터 정보를 담아 <CODE>forward_uri</CODE> 파라미터에 해당하는 페이지로 forward시킨다.
 * 따라서, Upload한 파일이 Image가 아니면 에러가 발생하며, 에러가 발생하면 에러 메시지를 <CODE>request</CODE>의 attribute에 <CODE>error_message</CODE>이라는 이름으로 담긴다.
 * 
 * <P>
 * 이를 위해 내부적으로 사용되는 파라미터들은 아래와 같으며 이때, 내부적으로 사용되는 파라미터와 동일한 이름의 파라미터가 필요할 경우에는 배열의 다음번째 값들에 담으면 된다.
 * 
 * <UL>
 *   <LI><CODE>forward_uri</CODE> - <CODE>multipart/form-data</CODE> 형식으로 넘어온 파라미터들을 <CODE>multipart_param</CODE>이라는 이름으로 담은 후 forward시킬 URI 주소.</LI>
 *   <LI><CODE>rewidth</CODE> - upload된 Image 파일을 변경할 가로폭.</LI>
 *   <LI><CODE>reheight</CODE> - upload된 Image 파일을 변경할 높이.</LI>
 * </UL>
 * 
 * <P>
 * upload된 Image file의 field name index에 해당하는 <CODE>rewidth</CODE>, <CODE>reheight</CODE> 배열의 index가 변경할 크기의 가로폭, 높이로 사용된다.
 * 만약 upload된 Image file의 field name 수보다 <CODE>rewidth</CODE> 혹은 <CODE>reheight</CODE> 배열 수가 적으면 마지막 배열의 값으로 나머지 <CODE>rewidth</CODE> 혹은 <CODE>reheight</CODE>로 사용되고,
 * <CODE>rewidth</CODE> 혹은 reheigh 값이 없으면 크기 변경을 하지 않는다.
 * 크기 변경이 가능한 이미지는 PNG, JPEG, GIF이며 이외의 이미지들은 크기 변경없이 원본 이미지를 Base64 기반의 문자열로만 변환된다.
 * 단, 동일한 upload된 Image file의 field name이 복수로 되어 있어도 <CODE>rewidth</CODE> 혹은 <CODE>reheight</CODE>은 하나의 배열 index로만 처리된다.
 * 
 * <P>
 * 이 때, <CODE>rewidth</CODE> 혹은 <CODE>reheight</CODE>는 실제 사용 가능한 이미지 크기 보다 너무 큰 이미지를 사용하지 못하게 하는 의도이므로
 * upload된 Image의 크기의 가로폭, 높이가 각각 <CODE>rewidth</CODE>, <CODE>reheight</CODE> 보다 작으면 크기 변환 작업을 하지 않는다.
 * 또한, 원본 이미지의 가로폭 높이의 비율을 유지 하기 위해 <CODE>rewidth</CODE>와 <CODE>reheight</CODE>가 모두 설정되어 있으면 비율 대비 좀더 작은 크기의 값으로 변경된다.
 * 
 * <P>
 * 파라미터들은 <CODE>multipart_param</CODE>에 아래의 규칙으로 담긴다.
 * 
 * <UL>
 *   <LI>단일 일반 파라미터 - <CODE>Map&lt;String, String&gt;</CODE> 형식으로 field name, field value가 담긴다.</LI>
 *   <LI>복수 일반 파라미터 - <CODE>Map&lt;String, String[]&gt;</CODE> 형식으로 field name에 배열로 복수개의 field value가 담긴다.</LI>
 *   <LI>단일 Upload file 파라미터 - <CODE>Map&lt;String, Map&lt;String, Object&gt;&gt;</CODE> 형식으로 field name에 파일 Image file 정보가 담긴다.</LI>
 *   <LI>복수 Upload file 파라미터 - <CODE>Map&lt;String, Map&lt;String, Object&gt;[]&gt;</CODE> 형식으로 하나의 field name에 파일 Image file 정보가 배열로 담긴다.</LI>
 * </UL>
 * 
 * <P>
 * upload된 Image file 정보는 아래와 같은 key에 정보의 값들이 담긴다.
 * 
 * <UL>
 *   <LI><CODE>name</CODE> - upload된 Image file 이름.</LI>
 *   <LI><CODE>value</CODE> - upload된 Image file의 이미지를 Base64로 변환한 {@link String} 값.</LI>
 *   <LI><CODE>inputStream</CODE> - upload된 Image file의 내용의 <CODE>InputStream</CODE> 값. 만약, 이미지를 Base64로 변환하지 않을려면 <CODE>inputStream</CODE>을 통해 직접 이미지를 처리할 수 있다.</LI>
 *   <LI><CODE>contentType</CODE> - upload된 file의 Content Type.</LI>
 *   <LI><CODE>size</CODE> - upload된 file의 크기의 long 값.</LI>
 * </UL>
 * 
 * <P>
 * <B>[URL의 이미지 파일을 로컬 도메인처럼 Proxy 처리]</B>
 * 
 * <P>
 * <CODE>request</CODE>의 파라미터가 <CODE>application/x-www-form-urlencoded</CODE> 형식으로 넘어오면 URL의 이미지 파일을 파싱하는 것으로 간주하고,
 * <CODE>url</CODE> 파라미터에 해당하는 페이지를 파싱해서 화면에 출력한다.
 * 내부적으로 사용되는 파라미터들은 아래와 같으며 이외의 값들은 <CODE>url</CODE> 파라미터에 해당하는 페이지를 호출하는 파라미터로 사용된다.
 * 이때, 내부적으로 사용되는 파라미터와 동일한 이름의 파라미터가 필요할 경우에는 배열의 다음번째 값들에 담으면 된다.
 * 
 * <UL>
 *   <LI><CODE>url</CODE> - Image 파일을 읽어올 URL 주소.</LI>
 *   <LI><CODE>contenttype</CODE> - URL 주소의 Image 파일을 읽어올 <CODE>request</CODE>의 content type.</LI>
 *   <LI><CODE>accept</CODE> - URL 주소의 Image 파일을 읽어올 <CODE>response</CODE>의 accept type.</LI>
 *   <LI><CODE>rewidth</CODE> - URL 주소의 Image 파일을 변경할 가로폭.</LI>
 *   <LI><CODE>reheight</CODE> - URL 주소의 Image 파일을 변경할 높이.</LI>
 * </UL>
 * 
 * <P>
 * <CODE>encoding</CODE>이 없으면 <CODE>UTF-8</CODE>로 처리되며, <CODE>contenttype</CODE>이 없으면 <CODE>application/x-www-form-urlencoded;charset=<I>${request_encoding}</I></CODE>로 처리된다.
 * <CODE><I>${request_encoding}</I></CODE>은 <CODE>request</CODE>의 <CODE>CharacterEncoding</CODE>에 설정된 값이며, 값이 없으면 <CODE>UTF-8</CODE>로 처리된다.
 * <CODE>accept</CODE>는 없으면 무시한다.
 * 
 * <P>
 * <CODE>ImageFileServlet</CODE>은 내부적으로 타 도메인에서 요청오면, <CODE>403</CODE> 상태코드로 내보내면서 "Not allow access from the cross domain" 메시지를 출력한다.
 * 따라서, <CODE>ImageFileServlet</CODE> 내부적으로 처리한 것과 비슷하게 <CODE>url</CODE>에 해당하는 페이지가 타 도메인 요청을 거부하도록 처리되어 있을 경우,
 * 해당 페이지를 읽어올 수 없다.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
@WebServlet(urlPatterns = "/servlet/com.jnodeframework.resolver.ImageFileServlet")
public class ImageFileServlet extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Server URL로부터 Image file을 읽어온다.
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		// Firefox는 origin이 헤더에 없으므로 referer로 처리하다.
		if (origin == null)  origin = request.getHeader("referer");

		if (origin == null || origin.indexOf(host) < 0) {
			// 타 도메인에서 요청온 것이므로 차단한다.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			serviceProxy(request, response);
		}
	}

	/**
	 * 업로드 혹은 Server URL로부터 Image file을 읽어온다.
	 * 
	 * <P>
	 * encoding type이 <CODE>multipart/form-data</CODE>이면 사용자의 Local 경로에 있는 Image File을 Upload해서 읽어오고,
	 * encoding type이 <CODE>application/x-www-form-urlencoded</CODE>이면 Server URL로부터 Image File을 읽어온다.
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String host   = request.getHeader("host");    // localhost:8080
		String origin = request.getHeader("origin");  // http://localhost:8080

		// Firefox는 origin이 헤더에 없으므로 referer로 처리하다.
		if (origin == null)  origin = request.getHeader("referer");

		if (origin == null || origin.indexOf(host) < 0) {
			// 타 도메인에서 요청온 것이므로 차단한다.
			response.sendError(403, "Not allow access from the cross domain");
		} else {
			if (ServletFileUpload.isMultipartContent(request)) {
				seriveClientImageFile(request, response);
			} else {
				serviceProxy(request, response);
			}
		}
	}

	/**
	 * 업로드한 파일로부터 Image file을 읽어온다.
	 * 
	 * @param  request   Image File을 읽어오기 위해 필요한 파라미터들을 담은 {@link HttpServletRequest} 객체
	 * @param  response  Image File을 읽어온 정보를 출력하기 위한 {@link HttpServletResponse} 객체
	 * @throws IOException       Image File을 읽어올 수 없을 때.
	 * @throws ServletException  dispatch시킬 수 없을 때.
	 */
	@SuppressWarnings("unchecked")
	private void seriveClientImageFile(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		try {
			String encoding     = request.getCharacterEncoding();
			String errorMessage = null;

			Map<String,Object> paramMap = new HashMap<String,Object>();

			// 복수값에 대한 처리를 위한 변수
			List<String> multiParamList = new ArrayList<String>();
			List<String> multiFileList  = new ArrayList<String>();
			List<String> fileList = new ArrayList<String>();
			ArrayList<String> arrlstParam = null;
			ArrayList<Map<String,Object>> arrlstFile = null;

			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);

			List<FileItem> items = upload.parseRequest(request);

			String fieldName  = null;
			String fieldValue = null;

			for (FileItem item : items) {
				fieldName  = item.getFieldName();

				if (item.isFormField()) {
					// 일반 form 필드일때
					if (encoding == null)  fieldValue = item.getString();
					else                   fieldValue = item.getString(encoding);

					if (paramMap.containsKey(fieldName)) {
						// 복수값에 대한 처리
						if (paramMap.get(fieldName) instanceof java.lang.String) {
							// 복수값임을 처음 알게 되었을 때
							multiParamList.add(fieldName);
							arrlstParam = new ArrayList<String>();
							arrlstParam.add((String)paramMap.get(fieldName));
							arrlstParam.add(fieldValue);
						} else {
							// 이미 복수값임을 알고 있을 때
							arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
							arrlstParam.add(fieldValue);
						}

						paramMap.put(fieldName, arrlstParam);
					} else {
						// 단수값에 대한 처리
						paramMap.put(fieldName, fieldValue);
					}
				} else {
					// binary 파일일때
					String contentType = item.getContentType();

					// Firefox에서는 webp를 이미지로 인식하지 못한다.
					// if (contentType.equals("application/octet-stream") && item.getName().toLowerCase().endsWith(".webp"))  contentType = "image/webp";

					if (contentType.startsWith("image/")) {
						Map<String,Object> imgFileMap = new HashMap<String,Object>();
						imgFileMap.put("name"       , item.getName());
						imgFileMap.put("contentType", contentType);
						imgFileMap.put("inputStream", item.getInputStream());
						imgFileMap.put("size"       , item.getSize());

						if (paramMap.containsKey(fieldName)) {
							// 복수값에 대한 처리
							if (paramMap.get(fieldName) instanceof java.util.Map) {
								// 복수값임을 처음 알게 되었을 때
								multiFileList.add(fieldName);
								arrlstFile = new ArrayList<Map<String,Object>>();
								arrlstFile.add((Map<String,Object>)paramMap.get(fieldName));
								arrlstFile.add(imgFileMap);
							} else {
								// 이미 복수값임을 알고 있을 때
								arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
								arrlstFile.add(imgFileMap);
							}

							paramMap.put(fieldName, arrlstFile);
						} else {
							// 단수 파일에 대한 처리
							paramMap.put(fieldName, imgFileMap);
							fileList.add(fieldName);
						}
					} else {
						errorMessage = "The upload file should be image format.";
						break;
					}
				}
			}

			// ArrayList로 임시로 저장했던 복수값을 String[]로 변환
			for (int i = 0; i < multiParamList.size(); i++) {
				fieldName = (String)multiParamList.get(i);
				arrlstParam = (ArrayList<String>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstParam.toArray(new String[arrlstParam.size()]));
			}

			// ArrayList로 임시로 저장했던 복수값을 Map[]로 변환
			for (int i = 0; i < multiFileList.size(); i++) {
				fieldName = (String)multiFileList.get(i);
				arrlstFile = (ArrayList<Map<String,Object>>)paramMap.get(fieldName);
				paramMap.put(fieldName, arrlstFile.toArray(new Map[arrlstFile.size()]));
			}

			// InputStream으로 담았던 파일 정보를 Base64 형태의 String으로 변환한다.
			// 이때 rewidth 혹은 reheight가 있으면 크기 변경을 처리한다.
			int fileSize = fileList.size();
			int[] rewidths  = null;
			int[] reheights = null;

			if (paramMap.containsKey("rewidth")) {
				if (paramMap.get("rewidth") instanceof java.lang.String) {
					rewidths = new int[1];
					rewidths[0] = Integer.parseInt((String)paramMap.get("rewidth"));
				} else {
					String[] rewidthStrings = (String[])paramMap.get("rewidth");

					rewidths = new int[rewidthStrings.length];
					for (int i = 0; i < rewidthStrings.length; i++) {
						rewidths[i] = Integer.parseInt(rewidthStrings[i]);
					}
				}

				int lastRewidth = rewidths[rewidths.length - 1];

				for (int i = rewidths.length; i < fileSize; i++) {
					rewidths[i] = lastRewidth;
				}
			}

			if (paramMap.containsKey("reheight")) {
				if (paramMap.get("reheight") instanceof java.lang.String) {
					reheights = new int[1];
					reheights[0] = Integer.parseInt((String)paramMap.get("reheight"));
				} else {
					String[] reheightStrings = (String[])paramMap.get("reheight");

					reheights = new int[reheightStrings.length];
					for (int i = 0; i < reheightStrings.length; i++) {
						reheights[i] = Integer.parseInt(reheightStrings[i]);
					}
				}

				int lastReheight = reheights[reheights.length - 1];

				for (int i = reheights.length; i < fileSize; i++) {
					reheights[i] = lastReheight;
				}
			}

			for (int i = 0; i < fileSize; i++) {
				fieldName = (String)fileList.get(i);

				Object objFile =paramMap.get(fieldName);

				if (objFile instanceof java.util.Map) {
					Map<String,Object> imgFileMap = (Map<String,Object>)objFile;

					String      contentType = (String)imgFileMap.get("contentType");
					InputStream inputStream = (InputStream)imgFileMap.get("inputStream");
					boolean     resizable   = contentType.toLowerCase().matches("^image/((png)|(jpg)|(jpeg)|(jpe)|(gif))$");

					if (!resizable || ((rewidths == null) && (reheights == null))) {
						// imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(IOUtils.toByteArray(inputStream))));
						imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(IOUtils.toByteArray(inputStream))));
					} else {
						BufferedImage bi = ImageIO.read(inputStream);
						int width  = bi.getWidth();
						int height = bi.getHeight();

						if ((rewidths != null) && (rewidths[i] > 0) && (rewidths[i] < width)) {
							height = height * rewidths[i] / width;
							width  = rewidths[i];
						}

						if ((reheights != null) && (reheights[i] > 0) && (reheights[i] < height)) {
							width  = width * reheights[i] / height;
							height = reheights[i];
						}

						BufferedImage bo = new BufferedImage(width, height, bi.getType());
						Graphics2D g2d = bo.createGraphics();
						g2d.drawImage(bi, 0, 0, width, height, null);
						g2d.dispose();

						ByteArrayOutputStream buffer = new ByteArrayOutputStream();
						ImageIO.write(bo, contentType.substring(6), buffer);
						// imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(buffer.toByteArray())));
						imgFileMap.put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(buffer.toByteArray())));
					}

					paramMap.put(fieldName, imgFileMap);
				} else {
					Map<String,Object>[] imgFileMaps = (Map<String,Object>[])objFile;

					for (int j = 0; j < imgFileMaps.length; j++) {
						String      contentType = (String)imgFileMaps[j].get("contentType");
						InputStream inputStream = (InputStream)imgFileMaps[j].get("inputStream");
						boolean     resizable   = contentType.toLowerCase().matches("^image/((png)|(jpg)|(jpeg)|(jpe)|(gif))$");

						if (!resizable || ((rewidths == null) && (reheights == null))) {
							// imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(IOUtils.toByteArray(inputStream))));
							imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(IOUtils.toByteArray(inputStream))));
						} else {
							BufferedImage bi = ImageIO.read(inputStream);
							int width  = bi.getWidth();
							int height = bi.getHeight();

							if ((rewidths != null) && (rewidths[i] > 0) && (rewidths[i] < width)) {
								height = height * rewidths[i] / width;
								width  = rewidths[i];
							}

							if ((reheights != null) && (reheights[i] > 0) && (reheights[i] < height)) {
								width  = width * reheights[i] / height;
								height = reheights[i];
							}

							BufferedImage bo = new BufferedImage(width, height, bi.getType());
							Graphics2D g2d = bo.createGraphics();
							g2d.drawImage(bi, 0, 0, width, height, null);
							g2d.dispose();

							ByteArrayOutputStream buffer = new ByteArrayOutputStream();
							ImageIO.write(bo, contentType.substring(6), buffer);
							// imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.encodeBase64(buffer.toByteArray())));
							imgFileMaps[j].put("value", "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(buffer.toByteArray())));
						}
					}

					paramMap.put(fieldName, imgFileMaps);
				}
			}

			request.setAttribute("multipart_param", paramMap);

			Object forwardUriObj = paramMap.get("forward_uri");
			String forwardUri = null;
			if (forwardUriObj instanceof String) {
				forwardUri = (String)forwardUriObj;
			} else if (forwardUriObj instanceof String[]) {
				forwardUri = ((String[])forwardUriObj)[0];
			}

			if (forwardUri == null) {
				throw new RuntimeException("forward_uri parameter is required.");
			}

			if (errorMessage != null) {
				request.setAttribute("error_message", errorMessage);
			}

			RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(forwardUri);
			dispatcher.forward(request, response);
		} catch (FileUploadException e) {
			throw new RuntimeException("Cannot load the local file.", e);
		}
	}
	

	/**
	 * 다른 도메인의 Server URL로부터 Image file을 읽어온다.
	 * 
	 * @param  request   Image File을 읽어오기 위해 필요한 파라미터들을 담은 {@link HttpServletRequest} 객체
	 * @param  response  Image File을 읽어온 정보를 출력하기 위한 {@link HttpServletResponse} 객체
	 * @throws IOException  Image File을 읽어올 수 없을 때 발생
	 */
	private void serviceProxy(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String targetUrl      = request.getParameter("url");
		String contenttype    = request.getParameter("contenttype");
		String accept         = request.getParameter("accept");
		String rewidthString  = request.getParameter("rewidth");
		String reheightString = request.getParameter("reheight");
		String reqEncoding    = request.getCharacterEncoding();
		String paramValue     = getParamValue(request);

		if (targetUrl   == null)  throw new RuntimeException("The URL address to load is empty");
		if (reqEncoding == null)  reqEncoding = "UTF-8";
		if (contenttype == null)  contenttype = "application/x-www-form-urlencoded;charset=" + reqEncoding;
		
		int rewidth  = -1;
		int reheight = -1;

		if (rewidthString  != null)  rewidth  = Integer.parseInt(rewidthString);
		if (reheightString != null)  reheight = Integer.parseInt(reheightString);

		URL url = new URL(targetUrl);

		HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
		urlConn.setRequestMethod(request.getMethod());
		urlConn.setDoOutput(true);
		urlConn.setDoInput(true);
		urlConn.setUseCaches(false);
		// urlConn.setFollowRedirects(false);

		urlConn.setRequestProperty("Content-Type", contenttype);

		if (accept != null)  urlConn.setRequestProperty("Accept", accept);

		if (paramValue != null) {
			DataOutputStream  output = new DataOutputStream(urlConn.getOutputStream());
			output.writeBytes(paramValue);
		}

		String      urlValue    = null;
		String      contentType = urlConn.getContentType();
		InputStream inputStream = urlConn.getInputStream();
		boolean     resizable   = contentType.toLowerCase().matches("^image/((png)|(jpg)|(jpeg)|(jpe)|(gif))$");

		if (!resizable || ((rewidth < 0) && (reheight < 0))) {
			// urlValue = "data:" + contentType + ";base64," + new String(Base64.encodeBase64(IOUtils.toByteArray(inputStream)));
			urlValue = "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(IOUtils.toByteArray(inputStream)));
		} else {
			BufferedImage bi = ImageIO.read(inputStream);
			int width  = bi.getWidth();
			int height = bi.getHeight();

			if ((rewidth > 0) && (rewidth < width)) {
				height = height * rewidth / width;
				width  = rewidth;
			}

			if ((reheight > 0) && (reheight < height)) {
				width  = width * reheight / height;
				height = reheight;
			}

			BufferedImage bo = new BufferedImage(width, height, bi.getType());
			Graphics2D g2d = bo.createGraphics();
			g2d.drawImage(bi, 0, 0, width, height, null);
			g2d.dispose();

			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			ImageIO.write(bo, contentType.substring(6), buffer);
			// urlValue = "data:" + contentType + ";base64," + new String(Base64.encodeBase64(buffer.toByteArray()));
			urlValue = "data:" + contentType + ";base64," + new String(Base64.getEncoder().encodeToString(buffer.toByteArray()));
		}

		response.setContentType("text/plain; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print(urlValue);
	}

	/**
	 * Server URL로부터 Image file을 읽어오기 위해 필요한 파라미터들을 문자열로 가져온다.
	 * 
	 * 파라미터 중 <CODE>url, encoding, contenttype, accept</CODE>은 Server URL로부터 Image File을 읽어오기 위해
	 * Servlet 내부에서 사용되는 값들이므로, 이들과 동일한 이름의 파라미터가 필요할 경우에는 배열의 두번째에 담기도록 해서 보내면 된다.
	 * 
	 * @param  request   Image File을 읽어오기 위해 필요한 파라미터들을 담은 {@link HttpServletRequest} 객체
	 * @return 파라미터들을 문자열로 바꾼 {@link String} 객체
	 * @throws UnsupportedEncodingException  {@link HttpServletRequest} 객체에서 문자로 변경할 때 지원하지 않는 encoding이 선언되었을 때
	 */
	private String getParamValue(HttpServletRequest request) throws UnsupportedEncodingException {
		Enumeration<String> enumParamName = request.getParameterNames();
		String encoding = request.getCharacterEncoding();

		if (encoding == null)  encoding = "UTF-8";

		StringBuffer parameterBuffer = new StringBuffer();

		while (enumParamName.hasMoreElements()) {
			String paramName = enumParamName.nextElement();
			String[] values = request.getParameterValues(paramName);
			int startIndex = 0;

			if (paramName.equals("url") || paramName.equals("encoding") || paramName.equals("contenttype") || paramName.equals("accept")) {
				startIndex = 1;
			}

			for (int i = startIndex; i < values.length; i++) {
				parameterBuffer.append("&").append(paramName).append("=").append(URLEncoder.encode(values[i], encoding));
			}
		}

		String paramValue = parameterBuffer.toString();

		if (paramValue.equals("")) {
			return null;
		} else {
			return paramValue.substring(1);
		}
	}
}
