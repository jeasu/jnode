/*
 * @(#)PageTemplate.java  1.3, 2014-03-28
 */
package com.jnodeframework.resolver;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Web Application의 페이지를 처리할 Template 파일을 <CODE>/WEB-INF/template/page</CODE>에서 찾아 Rendering해 주는 Servlet.
 * 
 * @version 1.3, 2014-03-28
 * @author  Jeasu Kim
 */
public class PageTemplate extends HttpServlet {

	/**
	 * default serial version ID.
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 요청받은 페이지를 <CODE>/WEB-INF/template/page</CODE>에서 찾아 Rendering한다.
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String template = getServletConfig().getInitParameter("template");
		String encoding = getServletConfig().getInitParameter("encoding");

		new TemplateResolver(request, response, template).renderTemplate((String)null, encoding);
	}
}