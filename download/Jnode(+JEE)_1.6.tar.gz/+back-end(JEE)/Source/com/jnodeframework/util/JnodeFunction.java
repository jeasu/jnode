/*
 * @(#)JnodeFunction.java  1.0, 2014-10-10
 */
package com.jnodeframework.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

import com.google.gson.Gson;

//import org.apache.commons.codec.binary.Base64;

/**
 * Jnode Back-end(JEE) 추가 모듈의 Function 관련 Utility Class.
 *
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class JnodeFunction {

	/**
	 * UTF-8 문자셋 Base64로 인코딩된 문자열을 디코딩한다.
	 * 
	 * @param  value  Base64로 디코딩할 문자열.
	 * @return Base64로 디코딩된 문자열.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String decodeBase64(String value) throws UnsupportedEncodingException {
		// return new String(Base64.decodeBase64(value.getBytes("UTF-8")));
		return new String(Base64.getDecoder().decode(value), "UTF-8");
	}

	/**
	 * Charset에 따라 URL 표기 형식으로 인코딩된 문자열을 디코딩한다.
	 * 
	 * @param  value    URL 표기 형식으로 인코딩된 문자열.
	 * @param  charset  문자셋.
	 * @return 디코딩된 문자열
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 * @since  Jnode Framework 1.6
	 */
	public static String decodeURL(String value, String charset) throws UnsupportedEncodingException {
		return URLDecoder.decode(value, charset);
	}

	/**
	 * Internet Explorer의 Friendly HTTP error messages 출력을 비활성화한다.
	 * 
	 * <P>
	 * Internet Explorer의 경우 에러가 발생했을 때 WAS Server에서 출력해주는 페이지 내용을 무시하고,
	 * Web Browser 자체적으로 Friendly error message로 출력해주는 기능이 기본으로 제공된다.
	 * 에러가 발생했을 때 Response로 받은 페이지의 크기가 512 bytes보다 적으면 WAS Server에서 출력하는 내용을 무시하고
	 * Web Browser 자체적으로 메시지 내용을 출력하는 기능이 있다.
	 * 
	 * <P>
	 * Client가 이 기능을 사용하지 않을려면 Client가 직접 "Tools &gt; Internet Options" 메뉴로 설정 화면을 띄운 뒤
	 * Advanced 탭에서 "Browsing &gt; Show friendly HTTP error messages" 항목의 체크를 제거해주어야 한다.
	 * 
	 * <P>
	 * Client의 설정에 상관없이 Friendly HTTP error messages 출력을 비활성화하는 방법은
	 * 더미 내용을 추가해서라도 512 bytes보다 크게 에러 페이지를 작성하는 방법과
	 * Web Browser가 에러로 인식하지 못하게 200 상태코드로 내려주는 방법이 있는데
	 * this function은 <CODE>200</CODE> 상태코드로 내려주는 방법을 제공한다.
	 * 
	 * <P>
	 * <CODE>exceptExts</CODE> 파라미터에 쉼표(<CODE>,</CODE>)를 구분자로 Friendly HTTP error messages 출력 비활성화 기능을 사용하지 않을 확장자를 설정할 수 있다.
	 * 
	 * @param pageContext  JSP 페이지 Context 객체.
	 * @param exceptExts   Friendly HTTP error messages 출력 비활성화 기능을 사용하지 않을 확장자들.
	 */
	public static void disableFriendlyErrorMessage(PageContext pageContext, String exceptExts) {
		HttpServletRequest  request  = (HttpServletRequest)pageContext.getRequest();
		HttpServletResponse response = (HttpServletResponse)pageContext.getResponse();

		disableFriendlyErrorMessage2(request, response, exceptExts);
	}

	/**
	 * Internet Explorer의 Friendly HTTP error messages 출력을 비활성화한다.
	 * 
	 * <P>
	 * Internet Explorer의 경우 에러가 발생했을 때 WAS Server에서 출력해주는 페이지 내용을 무시하고,
	 * Web Browser 자체적으로 Friendly error message로 출력해주는 기능이 기본으로 제공된다.
	 * 에러가 발생했을 때 Response로 받은 페이지의 크기가 512 bytes보다 적으면 WAS Server에서 출력하는 내용을 무시하고
	 * Web Browser 자체적으로 메시지 내용을 출력하는 기능이 있다.
	 * 
	 * <P>
	 * Client가 이 기능을 사용하지 않을려면 Client가 직접 "Tools &gt; Internet Options" 메뉴로 설정 화면을 띄운 뒤
	 * Advanced 탭에서 "Browsing &gt; Show friendly HTTP error messages" 항목의 체크를 제거해주어야 한다.
	 * 
	 * <P>
	 * Client의 설정에 상관없이 Friendly HTTP error messages 출력을 비활성화하는 방법은
	 * 더미 내용을 추가해서라도 512 bytes보다 크게 에러 페이지를 작성하는 방법과
	 * Web Browser가 에러로 인식하지 못하게 200 상태코드로 내려주는 방법이 있는데
	 * this function은 <CODE>200</CODE> 상태코드로 내려주는 방법을 제공한다.
	 * 
	 * <P>
	 * <CODE>exceptExts</CODE> 파라미터에 쉼표(<CODE>,</CODE>)를 구분자로 Friendly HTTP error messages 출력 비활성화 기능을 사용하지 않을 확장자를 설정할 수 있다.
	 * 
	 * @param request     Client 요청 객체.
	 * @param response    Server 응답 객체.
	 * @param exceptExts  Friendly HTTP error messages 출력 비활성화 기능을 사용하지 않을 확장자들.
	 */
	public static void disableFriendlyErrorMessage2(HttpServletRequest request, HttpServletResponse response, String exceptExts) {
		if (request.getParameter("template") == null || request.getParameter("requireType") == null || request.getParameter("nodeType") == null) {
			String errorRequestUri = (String)request.getAttribute("javax.servlet.error.request_uri");
			boolean hasExceptExt = false;

			if (!(errorRequestUri == null || exceptExts == null)) {
				String[] separatedExceptExts = exceptExts.split(",");

				for (String exceptExt : separatedExceptExts) {
					if (errorRequestUri.toLowerCase().endsWith("." + exceptExt.trim().toLowerCase())) {
						hasExceptExt = true;
						break;
					}
				}
			}

			if (!hasExceptExt) {
				response.setStatus(200);
			}
		}
	}

	/**
	 * 문자열을 UTF-8 문자셋 Base64로 인코딩한다.
	 * 
	 * @param  value  Base64로 인코딩할 문자열.
	 * @return Base64로 인코딩된 문자열.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String encodeBase64(String value) throws UnsupportedEncodingException {
		// return new String(Base64.encodeBase64(value.getBytes("UTF-8")));
		return new String(Base64.getEncoder().encodeToString(value.getBytes("UTF-8")));
	}

	/**
	 * 세션 정보를 JSON 형식의 문자열로 Base64 인코딩한다.
	 * 
	 * @param  pageContext  JSP 페이지의 Context 객체.
	 * @return Base64로 인코딩된 JSON 형식의 세션정보 {@link String}.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String encodeBase64Session(PageContext pageContext) throws UnsupportedEncodingException {
		HttpSession session = ((HttpServletRequest)(pageContext.getRequest())).getSession();
		return encodeBase64Session2(session);
	}

	/**
	 * 세션 정보를 JSON 형식의 문자열로 Base64 인코딩한다.
	 * 
	 * @param  session  HTTP Session 객체.
	 * @return Base64로 인코딩된 JSON 형식의 세션정보 {@link String}.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 */
	public static String encodeBase64Session2(HttpSession session) throws UnsupportedEncodingException {
		Enumeration<String> attributeNames = session.getAttributeNames();

		Map<String, Object> sessionMap = new HashMap<String, Object>();

		while (attributeNames.hasMoreElements()) {
			String attributeName = attributeNames.nextElement();
			sessionMap.put(attributeName, session.getAttribute(attributeName));
		}

		return encodeBase64(new Gson().toJson(sessionMap));
	}

	/**
	 * 문자열을 Charset에 맞게 URL 표기 형식으로 인코딩한다.
	 * 
	 * @param  value    URL 표기 형식으로 인코딩할 문자열.
	 * @param  charset  문자셋.
	 * @return URL 표기 형식으로 인코딩된 문자열.
	 * @throws UnsupportedEncodingException  The Character Encoding is not supported.
	 * @since  Jnode Framework 1.6
	 */
	public static String encodeURL(String value, String charset) throws UnsupportedEncodingException {
		return URLEncoder.encode(value, charset);
	}

	/**
	 * HTML의 문자열에서 사용할 수 있도록 {@link String} 값을 escape 문자 처리한다.
	 * 
	 * Tab 문자(<CODE>\t</CODE>)는 빈칸 4개로 변환한다.
	 * 
	 * @param  value  escape 문자 처리할 {@link String} 객체.
	 * @return HTML의 문자열에서 사용할 수 있도록 escape 문자 처리된 {@link String} 값.
	 */
	public static String escapeHTML(String value) {
		return escapeHTMLConsideredTab(value, 4);
	}

	/**
	 * Tab 문자(<CODE>\t</CODE>)를 변환할 빈칸 자리수를 설정하면서 HTML의 문자열에서 사용할 수 있도록 {@link String} 값을 escape 문자 처리한다.
	 * 
	 * @param  value      escape 문자 처리할 {@link String} 객체.
	 * @param  tabindent  Tab 문자(<CODE>\t</CODE>)를 변환할 빈칸의 자리수.
	 * @return HTML의 문자열에서 사용할 수 있도록 escape 문자 처리된 {@link String} 값.
	 */
	public static String escapeHTMLConsideredTab(String value, int tabindent) {
		if (value == null)  return null;

		String replacedTab = "";

		for (int i = 0; i < tabindent; i++) {
			replacedTab += " ";
		}

		return escapeXML(value).replaceAll("\t", replacedTab).replaceAll("(?m)^ ", "&nbsp;").replaceAll("(?m) $", "&nbsp;").replaceAll("  ", " &nbsp;").replaceAll("\r\n", "\n").replaceAll("\n", "<BR>");
	}

	/**
	 * JavaScript의 문자열에서 사용할 수 있도록 {@link String} 값을 escape 문자 처리한다.
	 * 
	 * @param  value  escape 문자 처리할 {@link String} 객체.
	 * @return JavaScript의 문자열에서 사용할 수 있도록 escape 문자 처리된 {@link String} 값.
	 * @since  Jnode Framework 1.6
	 */
	public static String escapeJS(String value) {
		if (value == null)  return null;

		return value.replaceAll("\\\\", "\\\\\\\\").replaceAll("\\\'", "\\\\\\\'").replaceAll("\\\"", "\\\\\\\"").replaceAll("\\\r", "\\\\\\r").replaceAll("\\\f", "\\\\\\f").replaceAll("\\\t", "\\\\\\t").replaceAll("\\\n", "\\\\\\n").replaceAll("\\\b", "\\\\\\b").replaceAll("<", "\\\\\\u003c").replaceAll(">", "\\\\\\u003e");
	}

	/**
	 * HTML의 INPUT(TEXTAREA 포함)의 문자열에서 사용할 수 있도록 {@link String} 값을 escape 문자 처리한다.
	 * 
	 * @param  value  escape 문자 처리할 {@link String} 객체.
	 * @return HTML의 INPUT(TEXTAREA 포함)의 문자열에서 사용할 수 있도록 escape 문자 처리된 {@link String} 값.
	 */
	public static String escapeXML(String value) {
		if (value == null)  return null;

		return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
	}
}