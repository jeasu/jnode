/*
 * @(#)Html5CheckFilter.java  1.0, 2014-10-10
 */
package kim.jeasu.jnode.framework.util;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * HTML5를 지원하는 브라우저로 접속했는지 체크하는 filter.
 * 
 * @version 1.0, 2014-10-10
 * @author  Jeasu Kim
 */
public class Html5CheckFilter implements Filter {

	/**
	 * filter 셋팅을 위한 환경설정 객체.
	 */
	protected FilterConfig filterConfig = null;

	/**
	 * filter 서비스 사용을 위해 web container에 의해 호출된다.
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
	}

	/**
	 * filter 서비스 종료를 위해 web container에 의해 호출된다.
	 */
	public void destroy() {
		this.filterConfig = null;
	}

	/**
	 * HTML5를 지원하는 브라우저로 접속했는지 체크한다.
	 * 
	 * <P>
	 * HTML5를 지원하지 않는 브라우저로 접속할 경우
	 * 지원하는 브라우저 목록 및 플러그인을 알려주는 페이지로 이동한다.
	 */
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest  request  = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse)res;

		String requestURI  = request.getRequestURI();
		String contextPath = request.getContextPath();
		String requestUriWoContextPath = requestURI.substring(contextPath.length());

		boolean skipHtml5Check = false;

		String joinedExclude = filterConfig.getInitParameter("exclude");
		String acceptIe      = filterConfig.getInitParameter("accept_ie");
		String[] excludes    = null;

		if (joinedExclude != null)  excludes = joinedExclude.trim().split("\n");

		for (String exclude : excludes) {
			exclude = exclude.trim();

			if (!exclude.equals("")) {
				if (exclude.endsWith("*")) {
					if (requestUriWoContextPath.startsWith(exclude.substring(0, exclude.length() - 1))) {
						skipHtml5Check = true;
						break;
					}
				} else if (exclude.startsWith("*")) {
					if (requestUriWoContextPath.endsWith(exclude.substring(1))) {
						skipHtml5Check = true;
						break;
					}
				} else {
					if (requestUriWoContextPath.equals(exclude)) {
						skipHtml5Check = true;
						break;
					}
				}
			}
		}

		if (skipHtml5Check) {
			chain.doFilter(request, response);
		} else {
			String userAgent = request.getHeader("user-agent");

			boolean acceptClient = true;
			boolean isTrident    = false;

			int   acceptIeVersion = 9;
			float tridentVersion  = 5;

			if (acceptIe == null) {
				acceptIeVersion = 9;
			} else {
				try {
					// 정수로만 입력받을 수 있게 int로 형변환한다.
					acceptIeVersion = Integer.parseInt(acceptIe);
					if (acceptIeVersion < 9)  acceptIeVersion = 9;
				} catch(Exception e) {}
			}

			if (userAgent.indexOf("Trident") > -1) {
				// "MSIE\\s\\d+\\.\\d+"
				// Real IE 8.0:     Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729)
				// Real IE 11.0:    Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko
				// Compatible mode: Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.3; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729; InfoPath.3)
				// Trident/3.1 -> IE7
				// Trident/4.0 -> IE8
				// Trident/5.0 -> IE9
				// Trident/6.0 -> IE10
				// Trident/7.0 -> IE11

				isTrident = true;
				Matcher tridentMatcher = Pattern.compile("Trident\\/\\d+\\.\\d+").matcher(userAgent);
				if (tridentMatcher.find()) {
					tridentVersion = Float.parseFloat(tridentMatcher.group().substring(8));
				}

				// IE 버전과 Trident 버전간의 차이가 4이므로
				if (tridentVersion < acceptIeVersion - 4) {
					acceptClient = false;
				}

				response.setHeader("X-UA-Compatible", "IE=Edge");
			}

			/*
			Chrome 14 and higher
			Firefox 7 and higher
			Opera 11 and higher
			Safari 5 and higher
			-----------------------------
			Mobile Safari 3.2 and higher
			Opera Mobile 5 and higher
			Android 2.1 and higher
			*/
			
			if (acceptClient) {
				chain.doFilter(request, response);
			} else {
				request.setAttribute("accept_version", String.valueOf(acceptIeVersion));

				if (acceptIeVersion == 9)  response.sendError(415, "Please check if your brower supports HTML5.");
				else                       response.sendError(415, "You should access with internet explorer ver." + acceptIeVersion + " or higher.");
			}
		}
	}
}